"""Summarize the original ERA5 monthly series for the study's supply regions."""
import csv
import gzip
import json
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parents[2]
MAP_DATA = ROOT / "04-data/geography/arcgis"
LAYERS = MAP_DATA / "layers"
BASELINE = {f"{year}-{month:02}" for year in range(1981, 2006) for month in range(1, 13)}
SOURCES = {"Arusha": "Tanzania", "Kilimanjaro": "Tanzania"}
COLUMNS = ["origin", "country", "months", "rain_mm_month", "temp_c"]


def save_features(name, records):
    path = LAYERS / f"{name}.geojson"
    path.write_text(json.dumps({"type": "FeatureCollection", "features": records},
                               separators=(",", ":")), encoding="utf-8")


def main():
    LAYERS.mkdir(exist_ok=True)
    weights = ROOT / "04-data/observed/catchment-origin-weights.csv"
    with weights.open(newline="", encoding="utf-8") as f:
        regions = {r["origin"] for r in csv.DictReader(f) if r["weighting"] == "equal"}
    assert len(regions) == 24
    monthly = {r: {} for r in regions}
    weather = ROOT / "04-data/sources/origin-month-spatial-weather.csv.gz"
    with gzip.open(weather, "rt", newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            origin, month = row["origin"], row["month"]
            if origin not in regions or month not in BASELINE:
                continue
            if month in monthly[origin]:
                raise ValueError(f"Duplicate ERA5 observation for {origin}, {month}")
            rain, temp = float(row["rain_mm"]), float(row["temp_c"])
            if not (rain >= 0 and -50 < temp < 60):
                raise ValueError(f"Invalid ERA5 value for {origin}, {month}")
            monthly[origin][month] = rain, temp

    result = {}
    for origin, values in sorted(monthly.items()):
        assert values.keys() == BASELINE, origin
        rain, temp = zip(*values.values())
        result[origin] = {"origin": origin, "country": SOURCES.get(origin, "Kenya"), "months": len(values),
                          "rain_mm_month": mean(rain), "temp_c": mean(temp)}
    with (MAP_DATA / "ERA5_Regional_Climatology_1981_2005.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, COLUMNS)
        writer.writeheader()
        writer.writerows(result.values())

    boundaries = MAP_DATA / "supply-regions.geojson"
    shapes = json.loads(boundaries.read_text(encoding="utf-8"))["features"]
    assert {f["properties"]["origin"] for f in shapes} == regions
    for f in shapes:
        f["properties"] = result[f["properties"]["origin"]]
    save_features("climatology", shapes)
    degrees = [([x, -6], [x, 6]) for x in range(34, 43, 2)]
    degrees.extend(([32, y], [43, y]) for y in range(-4, 6, 2))
    save_features("weather_graticule", [
        {"type": "Feature", "geometry": {"type": "LineString", "coordinates": ends}, "properties": {"id": i}}
        for i, ends in enumerate(degrees, 1)
    ])
    print(f"Verified {len(result)} regions × {len(BASELINE)} months ({len(result) * len(BASELINE):,} rows).")


if __name__ == "__main__":
    main()
