"""Render the two Kenya figures in ArcGIS Pro and package their layers."""
from copy import deepcopy
import csv
from functools import partial
import html
import json
from pathlib import Path
import shutil
import tempfile

import arcpy

ROOT = Path(__file__).resolve().parents[2]
MAP_DATA = ROOT / "04-data/geography/arcgis"
LAYERS = MAP_DATA / "layers"
OUTPUT = ROOT / "03-output/figures/arcgis"
PREFIX = "Kenya reference | "
CLIMATE = "Long-run weather in maize-supplying regions"
TRADE = "Kenya maize trade flows, first season 2008"
INK = (24, 43, 49)
GRAY = (83, 99, 105)
COAST = (145, 154, 154)
CONTEXT = (237, 235, 229)
PALE = (246, 245, 240)
WATER = (219, 236, 243)
WHITE = (255, 255, 255)
RAIN = [(236, 247, 246), (171, 216, 220), (80, 160, 185), (32, 105, 151), (21, 55, 99)]
TEMP = [(255, 245, 215), (243, 195, 129), (223, 128, 91), (161, 66, 81), (100, 40, 80)]
TRADE_COLORS = {
    "Within Kenya": (31, 74, 100),
    "Kenya border corridor": (175, 55, 48),
    "Nearby foreign route": (117, 113, 111),
}
STATUS_COLORS = {
    "Major production or surplus": (171, 210, 157),
    "Minor deficit": (248, 236, 180),
    "Major deficit": (233, 170, 113),
}
BORDER = (174, 53, 48)


def rgb(val, opacity=100):
    return {"RGB": [*val, opacity]}


def feature_layer(map_, path, name, query=None):
    layer = map_.addDataFromPath(path)
    layer.name = name
    if query:
        layer.definitionQuery = query
    return layer


def polygon_style(layer, face, edge, width=0.35, opacity=100):
    sym = layer.symbology
    sym.updateRenderer("SimpleRenderer")
    symbol = sym.renderer.symbol
    symbol.color = rgb(face, opacity)
    symbol.outlineColor = rgb(edge, 100 if width else 0)
    symbol.outlineWidth = width
    layer.symbology = sym


def line_style(layer, color, width):
    sym = layer.symbology
    sym.updateRenderer("SimpleRenderer")
    sym.renderer.symbol.color = rgb(color)
    sym.renderer.symbol.size = width
    layer.symbology = sym


def point_style(layer, color, edge, size, stroke=0.6):
    sym = layer.symbology
    sym.updateRenderer("SimpleRenderer")
    symbol = sym.renderer.symbol
    symbol.color = rgb(color)
    symbol.outlineColor = rgb(edge)
    symbol.outlineWidth = stroke
    symbol.size = size
    layer.symbology = sym


def shape_geometry(points, polygon=True):
    vertices = arcpy.Array([arcpy.Point(x, y) for x, y in points])
    return arcpy.Polygon(vertices) if polygon else arcpy.Polyline(vertices)


def rectangle(x, y, w, h):
    return shape_geometry([(x, y), (x, y+h), (x+w, y+h), (x+w, y), (x, y)])


def text(project, layout, x, y, message, size=9, color=INK, bold=False, font="Arial"):
    r, g, b = color
    content = f'<CLR red="{r}" green="{g}" blue="{b}">{html.escape(message)}</CLR>'
    item = project.createTextElement(layout, arcpy.Point(x, y), "POINT", content, size, font,
                                     "Bold" if bold else "Regular")
    item.setAnchor("BOTTOM_LEFT_CORNER")
    item.elementPositionX, item.elementPositionY = x, y
    return item


def cim_color(color):
    val = arcpy.cim.CreateCIMObjectFromClassName("CIMRGBColor", "V3")
    val.values = [*color, 100]
    return val


def graphic(project, layout, geometry, color, width=None):
    el = project.createGraphicElement(layout, geometry)
    definition = el.getDefinition("V3")
    symbol = definition.graphic.symbol.symbol
    if width is None:
        mark = arcpy.cim.CreateCIMObjectFromClassName("CIMSolidFill", "V3")
    else:
        mark = arcpy.cim.CreateCIMObjectFromClassName("CIMSolidStroke", "V3")
        mark.width = width
    mark.color, mark.enable = cim_color(color), True
    symbol.symbolLayers = [mark]
    el.setDefinition(definition)
    return el


def map_label(T, page, lon, lat, message, size=8.0, color=INK, bold=True):
    item = T(*page(lon, lat), message, size=size, color=color, bold=bold)
    definition = item.getDefinition("V3")
    mark = arcpy.cim.CreateCIMObjectFromClassName("CIMSolidFill", "V3")
    mark.color, mark.enable = cim_color(WHITE), True
    halo = arcpy.cim.CreateCIMObjectFromClassName("CIMPolygonSymbol", "V3")
    halo.symbolLayers = [mark]
    definition.graphic.symbol.symbol.haloSymbol = halo
    definition.graphic.symbol.symbol.haloSize = 0.76
    item.setDefinition(definition)


def new_map(project, name):
    map_ = project.createMap(PREFIX + name, "MAP")
    for layer in map_.listLayers():
        map_.removeLayer(layer)
    # Equirectangular meters, suitable near the equator for these extents.
    map_.spatialReference = arcpy.SpatialReference(4087)
    return map_


def place_frame(layout, map_, x, y, w, h, bounds, name):
    frame = layout.createMapFrame(rectangle(x, y, w, h), map_, name)
    from_sr = arcpy.SpatialReference(4326)
    to_sr = map_.spatialReference

    def to_xy(lon, lat):
        return arcpy.PointGeometry(arcpy.Point(lon, lat), from_sr).projectAs(to_sr).firstPoint

    lo, hi = to_xy(*bounds[:2]), to_xy(*bounds[2:])
    frame.camera.setExtent(arcpy.Extent(lo.X, lo.Y, hi.X, hi.Y))
    ext = frame.camera.getExtent()
    map_.defaultCamera.setExtent(ext)

    def page(lon, lat):
        pt = to_xy(lon, lat)
        return x + (pt.X - ext.XMin) * w / ext.width, y + (pt.Y - ext.YMin) * h / ext.height

    return page


def ramp_color(colors, t):
    pos = min(1, max(0, t)) * (len(colors)-1)
    i = min(int(pos), len(colors)-2)
    return tuple(round(a+(b-a)*(pos-i)) for a, b in zip(colors[i], colors[i+1]))


def continuous_fill(layer, values, field, limits, colors):
    sym = layer.symbology
    sym.updateRenderer("UniqueValueRenderer")
    sym.renderer.fields = ["origin"]
    lo, hi = limits
    ordered = set()
    for group in sym.renderer.groups:
        for item in group.items:
            region = item.values[0][0]
            value = values[region][field]
            ordered.add(region)
            item.label = f"{region}  {value:.1f}"
            item.symbol.color = rgb(ramp_color(colors, (value-lo)/(hi-lo)))
            item.symbol.outlineColor, item.symbol.outlineWidth = rgb(WHITE), 0.55
    assert ordered == set(values), ordered
    layer.symbology = sym


def colorbar(project, layout, T, x, y, unit, limits, colors, ticks):
    w, h, steps = 0.19, 2.06, 40
    lo, hi = limits
    T(x, y+h+0.13, unit, size=8.9, bold=True)
    for i in range(steps):
        graphic(project, layout, rectangle(x, y+h*i/steps, w, h/steps+0.002),
                ramp_color(colors, (i+0.5)/steps))
    for tick in ticks:
        position = y+h*(tick-lo)/(hi-lo)-0.047
        T(x+w+0.10, position, str(tick), size=8.3, color=GRAY)


def climate_layout(project, data):
    with (MAP_DATA / "ERA5_Regional_Climatology_1981_2005.csv").open(encoding="utf-8", newline="") as f:
        values = {r["origin"]: {key: float(r[key]) for key in ("rain_mm_month", "temp_c")}
                  for r in csv.DictReader(f)}
    assert len(values) == 24
    layout = project.createLayout(13.6, 8.25, "INCH", CLIMATE)
    T = partial(text, project, layout)
    T(0.53, 7.67, "Long-run weather in Kenya’s maize-supplying regions", size=24.4, font="Georgia")
    T(0.54, 7.32, "ERA5, 1981–2005  •  22 Kenyan counties and two supplying regions in northern Tanzania",
      size=10.4, color=GRAY)
    for x, label, measure, field, units, limits, scheme, ticks in [
        (0.58, "Rainfall", "Mean monthly precipitation total", "rain_mm_month", "mm/month",
         (40, 220), RAIN, [40, 80, 120, 160, 200, 220]),
        (7.15, "Air temperature", "Mean monthly air temperature at 2 m", "temp_c", "°C",
         (15, 28), TEMP, [16, 19, 22, 25, 28]),
    ]:
        T(x, 6.90, label, size=14.4, bold=True)
        T(x, 6.66, measure, size=8.9, color=GRAY)
        map_ = new_map(project, label)
        polygon_style(feature_layer(map_, data["countries"], "Countries"), (241, 239, 233), COAST, 0.38)
        polygon_style(feature_layer(map_, data["counties"], "Kenya county boundaries"),
                      (228, 231, 230), WHITE, 0.54)
        line_style(feature_layer(map_, data["weather_graticule"], "Longitude and latitude reference lines"),
                   (208, 212, 210), 0.34)
        displayed = feature_layer(map_, data["climatology"], f"Maize-weighted {label.lower()} normals")
        continuous_fill(displayed, values, field, limits, scheme)
        page = place_frame(layout, map_, x, 1.36, 5.09, 5.05, (33.32, -4.97, 42.40, 5.60), label)
        for longitude in (34, 36, 38, 40, 42):
            ref_x, _ = page(longitude, 0)
            T(ref_x-0.09, 1.17, f"{longitude}°E", size=7.6, color=GRAY)
        for latitude in (-4, -2, 0, 2, 4):
            _, ref_y = page(37, latitude)
            suffix = "" if latitude == 0 else "N" if latitude > 0 else "S"
            T(x-0.32, ref_y-0.035, f"{abs(latitude)}°{suffix}", size=7.6, color=GRAY)
        for lon, lat, name in [(38.18, 2.57, "KENYA"), (34.20, -4.18, "TANZANIA"),
                               (33.25, 1.81, "UGANDA")]:
            map_label(T, page, lon, lat, name, size=8.6, color=GRAY)
        colorbar(project, layout, T, x+5.29, 2.63, units, limits, scheme, ticks)
    T(0.55, 0.69, "Each region contributes 300 months. Within each region, ERA5 grid cells are weighted by MapSPAM rainfed maize harvested area.",
      size=8.6, color=GRAY)
    T(0.55, 0.40, "Sources  ERA5 · MapSPAM 2000 · geoBoundaries · Natural Earth. Kenyan counties outside the supply set appear in gray.",
      size=8.4, color=GRAY)
    return layout


def legend_arrow(project, layout, x, y, color, width):
    graphic(project, layout, shape_geometry([(x, y), (x+0.56, y)], polygon=False), color, width)
    h = 0.046 if width > 1.2 else 0.035
    graphic(project, layout, shape_geometry([(x+0.55, y-h), (x+0.55, y+h), (x+0.63, y)]), color)


def trade_scale(project, layout, T, page, x, y):
    a, _ = page(38.5, 0)
    b, _ = page(38.5 + 200/111.31949, 0)
    bar = b-a
    graphic(project, layout, rectangle(x, y, bar, 0.012), INK)
    for part, label in [(0.0, "0"), (0.5, "100"), (1.0, "200 km")]:
        pos = x + part*bar
        graphic(project, layout, rectangle(pos, y-0.035, 0.010, 0.08), INK)
        T(pos-0.034, y-0.15, label, size=7.5, color=GRAY)


def trade_layout(project, data):
    map_ = new_map(project, "2008 maize trade")
    layout = project.createLayout(13.3, 9.92, "INCH", TRADE)
    T = partial(text, project, layout)
    polygon_style(feature_layer(map_, data["trade_context"], "Neighboring countries", "country <> 'Kenya'"),
                  CONTEXT, COAST, 0.54)
    polygon_style(feature_layer(map_, data["trade_outline"], "Historical Kenya footprint"), PALE, COAST, 0.48)
    for category, color in STATUS_COLORS.items():
        layer = feature_layer(map_, data["trade_status"], category, f"category = '{category}'")
        polygon_style(layer, color, color, 0)
    polygon_style(feature_layer(map_, data["trade_districts"], "FEWS NET districts, 2007–2008"),
                  PALE, (171, 167, 146), 0.33, 0)
    polygon_style(feature_layer(map_, data["trade_lakes"], "Lakes"), WATER, (172, 198, 202), 0.5)
    for scope, color in TRADE_COLORS.items():
        for size, width in (("Small", 0.78), ("Large", 1.45)):
            where = f"scope = '{scope}' AND size = '{size}'"
            name = f"{scope} | {size.lower()} flow"
            line_style(feature_layer(map_, data["trade_routes"], name, where), color, width)
        polygon_style(feature_layer(map_, data["trade_arrowheads"], scope + " | arrowheads",
                                    f"scope = '{scope}'"), color, color, 0)
    point_style(feature_layer(map_, data["trade_markets"], "Market center", "border = 0"), INK, WHITE, 4.9)
    point_style(feature_layer(map_, data["trade_markets"], "Border market", "border = 1"), WHITE, BORDER, 6.0, 1.15)
    page = place_frame(layout, map_, 0.45, 0.90, 8.83, 7.85, (32.83, -5.05, 43.78, 5.65),
                       "Historical Kenyan maize routes")
    offsets = {
        "Lokichoggio": (0.09, 0.09), "Lodwar": (0.12, -0.08), "Mandera": (-0.76, 0.12),
        "Luuq": (0.08, -0.16), "Moyale": (0.10, -0.13), "Marsabit": (0.18, -0.06),
        "Wajir": (0.13, -0.11), "Maralal": (-0.63, 0.13), "Mbale": (-0.42, 0.12),
        "Busia": (-0.51, -0.12), "Malaba": (-0.63, 0.03), "Kitale": (-0.55, 0.11),
        "Eldoret": (0.12, -0.12), "Kisumu": (-0.53, -0.16), "Nakuru": (-0.58, -0.05),
        "Nyeri": (-0.50, 0.10), "Isiolo": (-0.60, 0.10), "Meru": (0.10, -0.15),
        "Garissa": (0.14, -0.07), "Kitui": (-0.12, 0.12), "Nairobi": (0.13, 0.0),
        "Kajiado": (-0.65, -0.14), "Isebania": (-0.72, -0.18), "Namanga": (0.15, -0.15),
        "Arusha": (-0.58, -0.16), "Taveta": (0.16, 0.09), "Mombasa": (0.13, -0.04),
    }
    markets = json.loads((LAYERS / "trade_markets.geojson").read_text(encoding="utf-8"))["features"]
    for feature in markets:
        name = feature["properties"]["market"]
        if name in offsets:
            lon, lat = feature["geometry"]["coordinates"]
            dx, dy = offsets[name]
            map_label(T, page, lon+dx, lat+dy, name,
                      size=7.7, color=BORDER if feature["properties"]["border"] else INK)
    for lon, lat, name in [(37.25, 5.10, "ETHIOPIA"), (35.85, 1.83, "KENYA"),
                           (33.1, 2.05, "UGANDA"), (42.10, 1.19, "SOMALIA"),
                           (34.23, -4.07, "TANZANIA"), (40.63, -3.15, "Indian Ocean"),
                           (35.93, 3.57, "Lake Turkana")]:
        map_label(T, page, lon, lat, name, size=8.4, color=GRAY, bold=not name.startswith("Lake"))

    T(0.49, 9.35, "Cross-border and internal maize trade in Kenya", size=25.5, font="Georgia")
    T(0.50, 8.98, "First-season market network drawn by FEWS NET in 2008", size=11.2, color=GRAY)
    T(0.72, 8.24, "N", size=8, bold=True)
    T(0.715, 8.06, "▲", size=9, bold=True)
    trade_scale(project, layout, T, page, 7.03, 1.38)

    xx = 9.62
    T(xx, 8.61, "Maize trade direction", size=13.4, bold=True)
    for i, (scope, color) in enumerate(TRADE_COLORS.items()):
        yy = 8.22 - i*0.38
        legend_arrow(project, layout, xx+0.04, yy+0.065, color, 1.45)
        T(xx+0.76, yy, scope, size=9.0)
    legend_arrow(project, layout, xx+0.04, 6.99, INK, 0.78)
    legend_arrow(project, layout, xx+0.04, 6.70, INK, 1.45)
    T(xx+0.76, 6.93, "Small flow in source map", size=8.5, color=GRAY)
    T(xx+0.76, 6.64, "Large flow in source map", size=8.5, color=GRAY)

    T(xx, 6.10, "First-season production status", size=12.5, bold=True)
    for i, (category, color) in enumerate(STATUS_COLORS.items()):
        yy = 5.69 - i*0.34
        graphic(project, layout, rectangle(xx+0.045, yy, 0.30, 0.17), color)
        T(xx+0.46, yy+0.01, category, size=8.9)
    T(xx, 4.33, "Market centers", size=12.5, bold=True)
    T(xx+0.08, 4.01, "●", size=10.5)
    T(xx+0.43, 4.03, "Market", size=8.9)
    T(xx+0.08, 3.67, "○", size=13.5, color=BORDER, bold=True)
    T(xx+0.43, 3.70, "Kenyan border market", size=8.9)

    T(xx, 3.06, "Reading the arrows", size=11, bold=True)
    notes = [
        "FEWS NET mapped typical market flows",
        "and ranked them by relative size.",
        "Red arrows mark parts of the network",
        "at or approaching Kenya’s border.",
        "The arrow paths are schematic.",
    ]
    for i, line in enumerate(notes):
        T(xx, 2.76 - 0.24*i, line, size=8.9, color=GRAY)

    T(0.46, 0.56, "Sources  FEWS NET/USGS first-season maize map (produced 24 July 2008) · FEWS NET historical district boundaries · Natural Earth",
      size=8.5, color=GRAY)
    T(0.46, 0.30, "Trade directions and production classifications were digitized from the source. Width represents a qualitative flow class.",
      size=8.3, color=GRAY)
    return layout


def data_stage(folder):
    layers = folder / "layers"
    shutil.copytree(LAYERS, layers)
    database = folder / "ReferenceMapData.gdb"
    arcpy.management.CreateFileGDB(str(folder), database.name)
    specs = {
        "countries": "POLYGON", "counties": "POLYGON", "climatology": "POLYGON",
        "weather_graticule": "POLYLINE", "trade_context": "POLYGON", "trade_outline": "POLYGON",
        "trade_lakes": "POLYGON", "trade_districts": "POLYGON", "trade_status": "POLYGON",
        "trade_markets": "POINT", "trade_routes": "POLYLINE", "trade_arrowheads": "POLYGON",
    }
    paths = {}
    for name, shape in specs.items():
        src = layers / f"{name}.geojson"
        expected = len(json.loads(src.read_text(encoding="utf-8"))["features"])
        paths[name] = str(database / name)
        arcpy.conversion.JSONToFeatures(str(src), paths[name], shape)
        assert int(arcpy.management.GetCount(paths[name])[0]) == expected > 0, name
    return paths


def package_project(project, stage, paths):
    path = stage / "Kenya_Maize_Climatology_and_Trade.aprx"
    project.saveACopy(str(path))
    editable = arcpy.mp.ArcGISProject(str(path))
    for layout in editable.listLayouts():
        if layout.name not in {CLIMATE, TRADE}:
            editable.deleteItem(layout)
    for map_ in editable.listMaps():
        if not map_.name.startswith(PREFIX):
            editable.deleteItem(map_)
    assert len(editable.listLayouts()) == 2 and len(editable.listMaps()) == 3
    editable.defaultGeodatabase = str(Path(paths["countries"]).parent)
    for obj in editable.listMaps():
        for layer in obj.listLayers():
            old = layer.connectionProperties
            new = deepcopy(old)
            new["connection_info"]["database"] = str(Path(paths[new["dataset"]]).parent)
            layer.updateConnectionProperties(old, new, validate=True)
            assert not layer.isBroken, (layer.name, layer.dataSource)
    editable.save()
    package = path.with_suffix(".ppkx")
    arcpy.management.PackageProject(str(path), str(package), "EXTERNAL",
                                    summary="Kenya maize ERA5 climatology and FEWS NET trade geography.",
                                    version="CURRENT", include_toolboxes="NO_TOOLBOXES",
                                    include_history_items="NO_HISTORY_ITEMS")
    shutil.copy2(package, OUTPUT / package.name)
    print("Exported both editable layouts and their GIS data")


def main():
    project = arcpy.mp.ArcGISProject("CURRENT")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    arcpy.env.overwriteOutput = True
    arcpy.env.addOutputsToMap = False
    for layout in project.listLayouts():
        if layout.name in {CLIMATE, TRADE}:
            project.deleteItem(layout)
    for map_ in project.listMaps():
        if map_.name.startswith(PREFIX):
            project.deleteItem(map_)
    stage = Path(tempfile.mkdtemp(prefix="kenya_maize_reference_"))
    paths = data_stage(stage)
    climate = climate_layout(project, paths)
    climate.exportToPNG(str(OUTPUT / "Kenya_Maize_ERA5_Climatology_1981_2005.png"), resolution=300)
    print("Exported Kenya climatology figure")
    trade = trade_layout(project, paths)
    trade.exportToPNG(str(OUTPUT / "Kenya_Maize_Trade_First_Season_2008.png"), resolution=300)
    print("Exported Kenya trade figure")
    climate.openView()
    package_project(project, stage, paths)


if __name__ == "__main__":
    main()
