"""Extract Kenya's first-season 2008 maize map as reproducible GIS features.

Requirements: numpy, pymupdf, pyshp, shapely. The original FEWS NET report
and public boundary files are retrieved if absent from the input cache.
"""
import argparse
import csv
import gzip
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from tempfile import gettempdir
from urllib.request import urlopen
from zipfile import ZipFile

import numpy as np
import pymupdf
import shapefile
from shapely import make_valid, transform
from shapely.geometry import LineString, Point, Polygon, box, mapping, shape
from shapely.geometry.polygon import orient
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[2]
MAP_DATA = ROOT / "04-data/geography/arcgis"
LAYERS = MAP_DATA / "layers"
RAW_PRICES = ROOT / "04-data/sources/fews-kenya-retail-maize-full.csv.gz"
SOURCE = "https://fews.net/east-africa/kenya/production-and-trade-flow-map/august-2008-1/print"
NATURAL_EARTH = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/"
URLS = {
    "map.pdf": SOURCE,
    "admin.zip": "https://fdw.fews.net/files/spatial/geographicunitset/KE_2007.zip",
    "world.geojson": NATURAL_EARTH + "ne_10m_admin_0_countries.geojson",
    "lakes.geojson": NATURAL_EARTH + "ne_10m_lakes.geojson",
}
COLORS = {(163, 255, 115): "Major production or surplus",
          (255, 255, 190): "Minor deficit", (255, 170, 0): "Major deficit"}
EXTENT = box(31.6, -6.5, 45.1, 6.6)
# Pixel centers on the original 1584 × 1224 PDF. The world coordinates of
# control towns come from FEWS NET price metadata, not the county series.
CONTROL = {
    "Lodwar": (338.4, 383.5), "Kitale": (281.7, 586.0), "Eldoret": (306.7, 634.0),
    "Nairobi": (455.9, 808.0), "Garissa": (728.1, 727.1), "Nyeri": (469.1, 724.3),
    "Wajir": (767.8, 516.2), "Marsabit": (567.3, 459.5), "Kajiado": (453.5, 863.1),
    "Kitui": (570.9, 814.6), "Meru": (535.4, 678.9), "Isiolo": (529.4, 649.9),
}
# Other marker centers read from the original PDF, including neighbors.
MARKETS = {
    "Lokichoggio": (214.2, 280.5), "Lodwar": CONTROL["Lodwar"], "Mandera": (942.2, 302.9),
    "Luuq": (1007.3, 319.2), "Moyale": (671.3, 345.0), "Marsabit": CONTROL["Marsabit"],
    "Baardheere": (981.5, 459.0), "Wajir": CONTROL["Wajir"], "Maralal": (444.5, 579.4),
    "Mbale": (158.6, 571.0), "Iganga": (133.7, 625.1), "Tororo": (202.0, 616.6),
    "Malaba": (210.7, 622.4), "Busia": (195.7, 642.2), "Bungoma": (245.2, 632.1),
    "Kitale": CONTROL["Kitale"], "Turbo": (285.4, 623.0), "Eldoret": CONTROL["Eldoret"],
    "Kisumu": (257.9, 693.5), "Nakuru": (384.5, 712.4), "Nyeri": CONTROL["Nyeri"],
    "Isiolo": CONTROL["Isiolo"], "Meru": CONTROL["Meru"], "Garissa": CONTROL["Garissa"],
    "Kitui": CONTROL["Kitui"], "Nairobi": CONTROL["Nairobi"], "Kajiado": CONTROL["Kajiado"],
    "Isebania": (259.4, 815.8), "Namanga": (453.0, 928.0), "Arusha": (442.3, 1008.3),
    "Taveta": (536.5, 1011.0), "Moshi": (506.8, 1005.7), "Mombasa": (729.6, 1074.5),
}
BORDER_MARKETS = {"Busia", "Malaba", "Isebania", "Namanga", "Taveta", "Moyale", "Mandera"}
# Color the trade segments at border approaches separately. A gap on the
# source map is retained as a gap. No missing segments are drawn.
BORDER_SECTIONS = {
    3317: "Uganda approach to Busia",
    3319: "Uganda approach to the Malaba corridor",
    3329: "Taveta corridor on the Kenya side",
    3375: "Arusha approach to Namanga from Tanzania",
    3377: "Namanga corridor on the Kenya side",
}
NEIGHBOR_SECTIONS = {3321, 3323, 3335, 3337, 3339}


def read_input(cache, name):
    target = cache / name
    if not target.exists():
        with urlopen(URLS[name], timeout=35) as response:
            target.write_bytes(response.read())
    return target


def vector_feature(geom, **props):
    return {"type": "Feature", "geometry": mapping(geom), "properties": props}


def save(name, records):
    (LAYERS / f"{name}.geojson").write_text(
        json.dumps({"type": "FeatureCollection", "features": records}, separators=(",", ":")),
        encoding="utf-8",
    )


def coordinates_to_world():
    control_world = {}
    with gzip.open(RAW_PRICES, "rt", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            name = r["market"]
            if name in CONTROL and r["longitude"] and r["latitude"]:
                control_world.setdefault(name, set()).add((float(r["longitude"]), float(r["latitude"])))
    assert set(control_world) == set(CONTROL) and all(len(v) == 1 for v in control_world.values())
    names = list(CONTROL)
    pixels = np.array([(*CONTROL[name], 1) for name in names])
    actual = np.array([next(iter(control_world[name])) for name in names])
    matrix, _, rank, _ = np.linalg.lstsq(pixels, actual, rcond=None)
    assert rank == 3
    error = 111.2 * np.linalg.norm(pixels @ matrix - actual, axis=1)
    assert error.max() < 6.0, list(zip(names, error.tolist()))

    def convert(x, y):
        return (matrix[0, 0] * x + matrix[1, 0] * y + matrix[2, 0],
                matrix[0, 1] * x + matrix[1, 1] * y + matrix[2, 1])

    with (MAP_DATA / "FEWS_2008_Georeference_Control_Points.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["market", "source_x_pt", "source_y_pt", "longitude", "latitude", "error_km"])
        writer.writerows((n, *CONTROL[n], *next(iter(control_world[n])), e) for n, e in zip(names, error))
    return convert, float(np.sqrt(np.mean(error**2)))


def paths(items):
    subpaths = []
    points = []
    for item in items:
        op = item[0]
        if op == "l":
            segment = [tuple(item[1]), tuple(item[2])]
        elif op == "c":
            a, b, c, d = (np.array(tuple(p)) for p in item[1:])
            segment = [tuple((1-t)**3*a + 3*(1-t)**2*t*b + 3*(1-t)*t*t*c + t**3*d)
                       for t in np.linspace(0, 1, 13)]
        else:
            raise ValueError(f"Unexpected command {op}")
        if points and np.linalg.norm(np.asarray(points[-1]) - segment[0]) < 0.02:
            points.extend(segment[1:])
        else:
            if points:
                subpaths.append(points)
            points = segment
    if points:
        subpaths.append(points)
    return subpaths


def polygons(geom):
    if geom.geom_type == "Polygon":
        yield geom
    elif hasattr(geom, "geoms"):
        for child in geom.geoms:
            yield from polygons(child)


def read_status(drawings, convert, kenya):
    for color, category in COLORS.items():
        pieces = []
        for e in drawings:
            fill = e.get("fill")
            if not fill or tuple(round(i * 255) for i in fill) != color:
                continue
            if e["rect"].x1 >= 1148 or e["rect"].y1 >= 1151:
                continue
            rings = [Polygon(s).simplify(0.55, preserve_topology=True) for s in paths(e["items"])
                     if len(s) >= 3]
            if rings:
                # Source fill uses the even-odd rule for nested paths.
                land = make_valid(rings[0])
                for ring in rings[1:]:
                    land = land.symmetric_difference(make_valid(ring))
                pieces.extend(polygons(land))
        assert len(pieces) > 45, category
        classified = unary_union(pieces)
        classified = transform(classified, convert, interleaved=False).intersection(kenya)
        for unit in polygons(classified):
            if unit.area > 0.00012:
                yield vector_feature(orient(unit), category=category)


def route_features(drawings, convert):
    shafts, heads, audit = [], [], []
    border, domestic, neighbor = "Kenya border corridor", "Within Kenya", "Nearby foreign route"
    for index in range(3317, 3389):
        e = drawings[index]
        if e["type"] != "s":
            continue
        head = drawings[index + 1]
        assert e["color"] == head["fill"] == (0, 0, 0) and len(head["items"]) == 3
        shaft, = paths(e["items"])
        triangle, = paths(head["items"])
        tri = Polygon(triangle)
        # Find whether the head points toward the stored start or end.
        if Point(shaft[0]).distance(tri) < Point(shaft[-1]).distance(tri):
            shaft.reverse()
        assert Point(shaft[-1]).distance(tri) < 0.2
        scope = border if index in BORDER_SECTIONS else neighbor if index in NEIGHBOR_SECTIONS else domestic
        size = "Large" if e["width"] > 2 else "Small"
        props = {"feature_id": len(shafts) + 1, "scope": scope, "size": size,
                 "pdf_path": index, "source_note": BORDER_SECTIONS.get(index, "")}
        shafts.append(vector_feature(transform(LineString(shaft), convert, interleaved=False), **props))
        heads.append(vector_feature(transform(tri, convert, interleaved=False), **props))
        start, end = convert(*shaft[0]), convert(*shaft[-1])
        audit.append({**props, "start_lon": start[0], "start_lat": start[1],
                      "end_lon": end[0], "end_lat": end[1]})
    assert len(shafts) == len(heads) == 35
    return shafts, heads, audit


def region_layers(cache):
    all_countries = json.loads(read_input(cache, "world.geojson").read_text(encoding="utf-8"))["features"]
    countries = []
    for f in all_countries:
        name = f["properties"]["ADMIN"]
        boundary = make_valid(shape(f["geometry"])).intersection(EXTENT)
        if boundary.area > 0.002:
            countries.append(vector_feature(boundary.simplify(0.012, preserve_topology=True), country=name))
    lake_source = json.loads(read_input(cache, "lakes.geojson").read_text(encoding="utf-8"))["features"]
    lake_shapes = []
    for f in lake_source:
        boundary = make_valid(shape(f["geometry"])).intersection(EXTENT)
        if boundary.area > 0.011:
            lake_shapes.append(vector_feature(boundary.simplify(0.007, preserve_topology=True),
                                             lake=f["properties"].get("name") or "Lake"))
    with ZipFile(read_input(cache, "admin.zip")) as z:
        reader = shapefile.Reader(shp=BytesIO(z.read("KE_Admin2_2007.shp")),
                                  shx=BytesIO(z.read("KE_Admin2_2007.shx")),
                                  dbf=BytesIO(z.read("KE_Admin2_2007.dbf")))
        districts = [vector_feature(make_valid(shape(s.shape.__geo_interface__)).simplify(0.008, preserve_topology=True),
                                     district_id=i) for i, s in enumerate(reader.iterShapeRecords(), 1)]
    return countries, lake_shapes, districts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=Path(gettempdir()) / "kenya-fews-trade-source")
    args = parser.parse_args()
    cache = args.cache
    cache.mkdir(exist_ok=True)
    LAYERS.mkdir(exist_ok=True)
    original = read_input(cache, "map.pdf")
    with pymupdf.open(original) as doc:
        page = doc[0]
        assert tuple(page.rect) == (0, 0, 1584, 1224) and "FIRST SEASON MAIZE" in page.get_text()
        drawings = page.get_drawings()
        assert len(drawings) == 3445
    convert, rmse = coordinates_to_world()
    source_sha = sha256(original.read_bytes()).hexdigest()
    countries, lakes, districts = region_layers(cache)
    kenya = unary_union([shape(f["geometry"]) for f in districts])
    status = list(read_status(drawings, convert, kenya))
    arrows, heads, audit = route_features(drawings, convert)
    markets = [vector_feature(Point(convert(*point)), market=name,
                              border=int(name in BORDER_MARKETS)) for name, point in MARKETS.items()]
    for name, rows in {
        "trade_context": countries, "trade_lakes": lakes, "trade_districts": districts,
        "trade_outline": [vector_feature(kenya, country="Kenya")],
        "trade_status": status, "trade_routes": arrows, "trade_arrowheads": heads, "trade_markets": markets,
    }.items():
        save(name, rows)
    with (MAP_DATA / "FEWS_2008_Digitized_Maize_Routes.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, list(audit[0]))
        writer.writeheader()
        writer.writerows(audit)
    metadata = {"source_url": SOURCE, "source_sha256": source_sha, "georeference_rmse_km": rmse,
                "control_towns": len(CONTROL), "routes": len(arrows), "markets": len(markets)}
    (MAP_DATA / "trade_source_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
