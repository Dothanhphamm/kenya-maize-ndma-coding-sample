* Estimate crop-phase weather associations with maize price inflation and volatility.
* Kenya NDMA white maize retail prices, 2008-2014; weather baseline 1981-2005.
* Run from the bundle root, or pass a panel CSV and an output directory.
*   do 02-analysis/stata/estimate_weather_models.do
*   do "02-analysis/stata/estimate_weather_models.do" "path/to/panel.csv" "path/to/results"
version 16.0
clear all
set more off
args panel output_dir
if `"`panel'"' == "" local panel "04-data/observed/ndma-market-month-panel.csv"
if `"`output_dir'"' == "" local output_dir "03-output/results"
capture mkdir "`output_dir'"

import delimited using "`panel'", varnames(1) asdouble clear
assert source_organization == "NDMA, Kenya"
assert white_maize_retail_kes_per_kg > 0 if !missing(white_maize_retail_kes_per_kg)
assert missing(white_maize_retail_kes_per_kg) == (price_status == "Not Collected")
gen int ym = monthly(month, "YM")
isid market_id ym, sort
xtset market_id ym, monthly

// Calendar lags require two observed prices for inflation and seven for volatility.
gen double log_price = ln(white_maize_retail_kes_per_kg)
gen double inflation = 100 * D.log_price
gen double mean_change = (inflation + L.inflation + L2.inflation + ///
    L3.inflation + L4.inflation + L5.inflation) / 6
gen double sum_squares = 0
forvalues lag = 0/5 {
    quietly replace sum_squares = sum_squares + (L`lag'.inflation - mean_change)^2
}
gen double volatility = sqrt(sum_squares / 5)
assert missing(inflation) == missing(maize_inflation_pp)
assert missing(volatility) == missing(maize_inflation_volatility_pp)
assert abs(inflation - maize_inflation_pp) < 1e-8 if !missing(inflation)
assert abs(volatility - maize_inflation_volatility_pp) < 1e-8 if !missing(volatility)

// Make all lags before filtering any sample so a gap never becomes a one-month lag.
foreach outcome in inflation volatility {
    gen double lag_`outcome' = L.`outcome'
}
bysort market_id: egen byte complete_series = min(!missing(white_maize_retail_kes_per_kg))

// The phases in the input are already lagged to their last completed occurrences.
foreach phase in plant grow harvest {
    foreach kind in rain_mm chirps_mm temp_c {
        assert !missing(`phase'_`kind')
        gen double `phase'_`kind'_deficit = max(-`phase'_`kind', 0)
        gen double `phase'_`kind'_excess = max(`phase'_`kind', 0)
    }
}

mata:
// Estimate the model after removing market and year-month fixed effects.
// Weather comes first in xvars. The optional last column is the lagged outcome.
void fit_phase_model(string scalar yvar, string scalar xvars, real scalar baseline_mse)
{
    real matrix x, bread, scores, meat, cross, covariance, weather_inverse
    real colvector y, month, coef, residual, se, half_width, weather_index, weather_coef
    real scalar n, first, i, row, lag, bandwidth, calendar_df, mse, f

    y = st_data(., yvar)
    x = st_data(., tokens(xvars))
    month = st_data(., "ym")
    n = rows(x)
    first = min(month)
    calendar_df = rows(uniqrows(month)) - 1

    bread = invsym(quadcross(x, x))
    assert(all(diagonal(bread) :> 0))
    coef = bread * quadcross(x, y)
    residual = y - x * coef
    mse = quadcross(residual, residual) / n

    // Sum scores within months, then use Bartlett HAC over the monthly scores.
    // This permits common shocks across markets and serial dependence.
    scores = J(max(month) - first + 1, cols(x), 0)
    for (i = 1; i <= n; i++) {
        row = month[i] - first + 1
        scores[row, .] = scores[row, .] + x[i, .] * residual[i]
    }
    bandwidth = 12
    meat = quadcross(scores, scores)
    for (lag = 1; lag <= min((bandwidth, rows(scores) - 1)); lag++) {
        cross = quadcross(scores[|1,1 \ rows(scores)-lag,cols(x)|],
                           scores[|1+lag,1 \ rows(scores),cols(x)|])
        meat = meat + (1 - lag / (bandwidth + 1)) * (cross + cross')
    }
    covariance = bread * meat * bread
    se = sqrt(diagonal(covariance))
    half_width = invttail(calendar_df, .025) * se

    // Test the 12 weather coefficients jointly, conditional on the outcome lag
    // when it is included. Use the weather block of the full covariance.
    weather_index = 1::12
    weather_coef = coef[weather_index]
    weather_inverse = invsym(covariance[weather_index, weather_index])
    assert(all(diagonal(weather_inverse) :> 0))
    f = (weather_coef' * weather_inverse * weather_coef) / rows(weather_index)
    st_matrix("coefficients", (coef, se, coef - half_width, coef + half_width,
                               2 * ttail(calendar_df, abs(coef :/ se))))
    st_matrix("fit", (mse, 100 * (1 - mse / baseline_mse), f,
                      rows(weather_index), calendar_df, Ftail(rows(weather_index), calendar_df, f)))
}
end

tempfile full_panel fit_rows coefficient_rows
tempname fit_handle coef_handle
save "`full_panel'"
postfile `fit_handle' str13 sample str10 outcome str14 model str6 rainfall ///
    int (n_obs markets months) str7 first_month str7 last_month ///
    double (baseline_mse weather_mse mse_reduction_pct weather_f) ///
    int (weather_df calendar_df) double weather_p using "`fit_rows'"
postfile `coef_handle' str13 sample str10 outcome str14 model str6 rainfall ///
    str28 term double (coef se ci_low ci_high p) using "`coefficient_rows'"

foreach sample in all_markets balanced geography {
    quietly use "`full_panel'", clear
    if "`sample'" == "balanced" keep if complete_series
    if "`sample'" == "geography" keep if geography_flag == 0

    foreach outcome in inflation volatility {
        foreach window in full matched {
            preserve
            quietly keep if !missing(`outcome')
            local models "static"
            if "`window'" == "matched" {
                quietly keep if !missing(lag_`outcome')
                local models "static_matched dynamic"
            }

            local n_obs = _N
            egen byte tag_market = tag(market_id)
            quietly count if tag_market
            local markets = r(N)
            egen byte tag_month = tag(ym)
            quietly count if tag_month
            local months = r(N)
            quietly summarize ym, meanonly
            local first = string(r(min), "%tmCCYY-NN")
            local last = string(r(max), "%tmCCYY-NN")

            // Year-month effects absorb common monthly prices and exchange rates.
            // Market effects absorb time-invariant distances.
            quietly regress `outcome' i.market_id i.ym
            assert e(N) == `n_obs'
            local static_mse = e(rss) / e(N)
            quietly predict double within_outcome, residuals

            if "`window'" == "matched" {
                quietly regress `outcome' i.market_id i.ym lag_`outcome'
                assert e(N) == `n_obs'
                local dynamic_mse = e(rss) / e(N)
                quietly regress lag_`outcome' i.market_id i.ym
                quietly predict double within_lag, residuals
            }

            // Fit each weather term once on these rows. Both rainfall products
            // share the temperature adjustment. Both matched models share all
            // weather adjustments.
            foreach phase in plant grow harvest {
                foreach kind in rain_mm chirps_mm temp_c {
                    foreach direction in deficit excess {
                        local term `phase'_`kind'_`direction'
                        quietly regress `term' i.market_id i.ym
                        quietly predict double r_`term', residuals
                    }
                }
            }

            sort ym market_id
            foreach model of local models {
                local baseline_mse `static_mse'
                if "`model'" == "dynamic" local baseline_mse `dynamic_mse'

                foreach product in era5 chirps {
                    local rain rain_mm
                    if "`product'" == "chirps" local rain chirps_mm
                    local terms
                    local rhs
                    foreach phase in plant grow harvest {
                        foreach kind in `rain' temp_c {
                            foreach direction in deficit excess {
                                local term `phase'_`kind'_`direction'
                                local terms `terms' `term'
                                local rhs `rhs' r_`term'
                            }
                        }
                    }
                    if "`model'" == "dynamic" {
                        local terms `terms' lag_`outcome'
                        local rhs `rhs' within_lag
                    }

                    mata: fit_phase_model("within_outcome", "`rhs'", `baseline_mse')
                    post `fit_handle' ("`sample'") ("`outcome'") ("`model'") ("`product'") ///
                        (`n_obs') (`markets') (`months') ("`first'") ("`last'") ///
                        (`baseline_mse') (fit[1,1]) (fit[1,2]) (fit[1,3]) (fit[1,4]) (fit[1,5]) (fit[1,6])

                    local i = 0
                    foreach term of local terms {
                        local ++i
                        post `coef_handle' ("`sample'") ("`outcome'") ("`model'") ///
                            ("`product'") ("`term'") (coefficients[`i',1]) (coefficients[`i',2]) ///
                            (coefficients[`i',3]) (coefficients[`i',4]) (coefficients[`i',5])
                    }
                }
            }
            restore
        }
    }
}

postclose `fit_handle'
postclose `coef_handle'
use "`fit_rows'", clear
format baseline_mse weather_mse mse_reduction_pct weather_f weather_p %24.16g
sort sample outcome model rainfall
export delimited using "`output_dir'/model-fit.csv", datafmt replace

use "`coefficient_rows'", clear
format coef se ci_low ci_high p %24.16g
sort sample outcome model rainfall term
export delimited using "`output_dir'/coefficients.csv", datafmt replace
