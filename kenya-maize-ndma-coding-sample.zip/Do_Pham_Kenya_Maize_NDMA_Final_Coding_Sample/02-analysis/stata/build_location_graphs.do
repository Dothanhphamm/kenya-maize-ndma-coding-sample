* Location exhibits. Run build_graphs.do from the package root.
* Weather panels show growing areas; volatility panels show price-reporting locations.

frame change plot_inputs
import delimited "`project'/04-data/observed/origin-month-weather-anomalies.csv", asdouble clear
generate int ym = monthly(month, "YM")
assert !missing(ym)
isid origin ym
keep if inrange(ym, tm(1981m1), tm(2005m12))

// Show contrasting growing areas from the west and highlands to the east and coast.
local areas `""Trans Nzoia" Nyandarua Meru Narok Kitui Kilifi"'
generate byte panel = .
local index = 0
foreach area of local areas {
    local ++index
    quietly replace panel = `index' if origin == "`area'"
    quietly count if panel == `index'
    assert r(N) == 300
}
keep if !missing(panel)
generate byte calendar_month = month(dofm(ym))
keep origin panel ym calendar_month rain_mm temp_c
assert !missing(rain_mm, temp_c)
assert rain_mm >= 0
assert inrange(temp_c, 12, 30)
rename (rain_mm temp_c) (weather_value1 weather_value2)
reshape long weather_value, i(origin ym) j(variable)
generate str11 measure = cond(variable == 1, "Rainfall", "Temperature")

// Compute one distribution across baseline years for each area and calendar month.
bysort variable panel calendar_month (ym): generate byte group_row = _n == 1
by variable panel calendar_month: generate byte n_years = _N
assert n_years == 25
by variable panel calendar_month: egen double mean_value = mean(weather_value)
by variable panel calendar_month: egen double q1 = pctile(weather_value), p(25)
by variable panel calendar_month: egen double median_value = median(weather_value)
by variable panel calendar_month: egen double q3 = pctile(weather_value), p(75)
generate double iqr = q3 - q1
generate byte in_fences = inrange(weather_value, q1 - 1.5 * iqr, q3 + 1.5 * iqr)
by variable panel calendar_month: egen double whisker_low = min(cond(in_fences, weather_value, .))
by variable panel calendar_month: egen double whisker_high = max(cond(in_fences, weather_value, .))
by variable panel calendar_month: egen byte n_outliers = total(!in_fences)
assert whisker_low <= q1 & q1 <= median_value & median_value <= q3 & q3 <= whisker_high
generate double outlier_value = weather_value if !in_fences
generate double box_left = calendar_month - .26
generate double box_right = calendar_month + .26

preserve
    keep if group_row
    generate str7 units = cond(variable == 1, "mm", "deg C")
    sort variable panel calendar_month
    isid measure origin calendar_month
    assert _N == 144
    format mean_value q1 median_value q3 whisker_low whisker_high %21.14g
    export delimited measure origin calendar_month units n_years mean_value q1 median_value q3 ///
        whisker_low whisker_high n_outliers using "`results'/monthly-weather-distributions.csv", datafmt replace
restore

program define plot_monthly_weather
    args area_index variable_id heading graphname
    if `variable_id' == 1 {
        local fill "216 230 239"
        local stroke "31 66 91"
        local base 0
        local y_ticks "#5"
        local y_limits ""
    }
    else {
        local fill "244 226 221"
        local stroke "128 59 47"
        local base 12
        local y_ticks "12(6)30"
        local y_limits "range(12 30)"
    }
    preserve
    keep if panel == `area_index' & variable == `variable_id'
    assert _N == 300
    twoway (bar mean_value calendar_month if group_row, barwidth(.84) base(`base') ///
                fcolor("`fill'") lcolor("`fill'") fintensity(100)) ///
           (rspike whisker_low whisker_high calendar_month if group_row, ///
                lcolor("`stroke'") lwidth(.55pt)) ///
           (rbar q1 q3 calendar_month if group_row, barwidth(.52) ///
                fcolor(white) fintensity(100) lcolor("`stroke'") lwidth(.65pt)) ///
           (rspike box_left box_right median_value if group_row, horizontal ///
                lcolor("`stroke'") lwidth(1pt)) ///
           (scatter outlier_value calendar_month if !in_fences, ///
                msymbol(O) mcolor("`stroke'") msize(2.6pt)), ///
        xlabel(1 "Jan" 3 "Mar" 5 "May" 7 "Jul" 9 "Sep" 11 "Nov", ///
            labsize(9pt) labcolor(black) nogrid noticks) ///
        ylabel(`y_ticks', angle(horizontal) labsize(9pt) labcolor(black) ///
            labelminlen(3) grid glcolor(gs14) glpattern(solid) glwidth(vthin) noticks) ///
        xscale(range(.45 12.55) noline) yscale(`y_limits' noline) ///
        title("{fontface Arial:{bf:`heading'}}", size(12pt) color(black) pos(11) span margin(b=5pt)) ///
        xtitle("") ytitle("") legend(off) graphregion(color(white)) ///
        plotregion(lcolor(none) margin(zero)) name(`graphname', replace) nodraw
    restore
end

local rain_graphs
local temp_graphs
local index = 0
foreach area of local areas {
    local ++index
    plot_monthly_weather `index' 1 "`area'" rain_`index'
    plot_monthly_weather `index' 2 "`area'" temp_`index'
    local rain_graphs `rain_graphs' rain_`index'
    local temp_graphs `temp_graphs' temp_`index'
}

graph combine `rain_graphs', cols(3) xcommon imargin(5pt 6pt 5pt 9pt) iscale(1) ///
    title("{fontface Arial:{bf:Figure 6a. Monthly rainfall in maize-supplying areas}}", `figure_title') ///
    subtitle("ERA5 monthly rainfall totals (mm), 1981-2005", `figure_subtitle') ///
    b1title("Calendar month", size(10pt) color(black) margin(t=6pt)) ///
    note("{it:Notes.} Bars show 25-year averages. Boxes span the 25th to 75th percentiles, with a line at the median." ///
         "Whiskers reach the last values within 1.5 interquartile ranges of each box. Dots mark values beyond them." ///
         "The rainfall scale varies by area. ERA5 values use maize-area weights within each growing area.", `figure_note') ///
    `figure_size' ysize(7.1)
save_figure "`output'/figure-6a-monthly-rainfall"

graph combine `temp_graphs', cols(3) xcommon ycommon imargin(5pt 6pt 5pt 9pt) iscale(1) ///
    title("{fontface Arial:{bf:Figure 6b. Monthly temperature in maize-supplying areas}}", `figure_title') ///
    subtitle("ERA5 monthly mean 2 m air temperature (°C), 1981-2005", `figure_subtitle') ///
    b1title("Calendar month", size(10pt) color(black) margin(t=6pt)) ///
    note("{it:Notes.} Bars show 25-year averages and start at 12 °C. Boxes span the middle 50%, with a line at the median." ///
         "Whiskers reach the last values within 1.5 interquartile ranges of each box. Dots mark values beyond them." ///
         "ERA5 values use maize-area weights within each growing area.", `figure_note') ///
    `figure_size' ysize(7.1)
save_figure "`output'/figure-6b-monthly-temperature"

// Figure 7. Use the volatility series reconstructed and checked by estimate_weather_models.do.
// Arrange the market panels roughly from north to south and west to east.
frame change default
rename maize_inflation_volatility_pp volatility_pp
local markets `"Turkana Marsabit Mandera "West Pokot" Nyeri-Kieni Garissa Narok "Taita Taveta" Kwale"'
generate byte panel = .
local index = 0
foreach market_name of local markets {
    local ++index
    quietly replace panel = `index' if market == "`market_name'"
}
keep if !missing(panel)
assert _N == 9 * 84
assert geography_flag == 0
assert missing(volatility_pp) if ym < tm(2008m7)
assert !missing(volatility_pp) if ym >= tm(2008m7) & ///
    !(market == "Narok" & inrange(ym, tm(2010m11), tm(2011m6)))
assert missing(volatility_pp) if market == "Narok" & inrange(ym, tm(2010m11), tm(2011m6))

generate double lowess_pp = .
local volatility_graphs
local first = tm(2008m1)
local final_jan = tm(2014m1)
local last = tm(2014m12)
local index = 0
foreach market_name of local markets {
    local ++index
    quietly lowess volatility_pp ym if panel == `index', bwidth(.30) generate(fitted) nograph
    quietly replace lowess_pp = fitted if panel == `index'
    drop fitted
    twoway (line volatility_pp ym if panel == `index', sort cmissing(n) ///
                lcolor("31 66 91") lwidth(.7pt)) ///
           (line lowess_pp ym if panel == `index', sort cmissing(n) ///
                lcolor("157 71 53") lwidth(.9pt)), ///
        xlabel(`first'(24)`final_jan', format(%tmCCYY) labsize(9pt) labcolor(black) ///
            nogrid tlength(tiny) tlcolor(gs8)) ///
        ylabel(0(10)30, angle(horizontal) labsize(9pt) labcolor(black) ///
            grid glcolor(gs14) glpattern(solid) glwidth(vthin) noticks) ///
        xscale(range(`first' `last') lcolor(gs8) lwidth(vthin)) ///
        yscale(range(0 35) noline) ///
        title("{fontface Arial:{bf:`market_name'}}", size(12pt) color(black) pos(11) span margin(b=4pt)) ///
        xtitle("") ytitle("") legend(off) graphregion(color(white)) ///
        plotregion(lcolor(none) margin(l=1 r=1 t=0 b=0)) name(market_`index', replace) nodraw
    local volatility_graphs `volatility_graphs' market_`index'
}
assert missing(volatility_pp) == missing(lowess_pp)
assert inrange(volatility_pp, 0, 35) if !missing(volatility_pp)
assert inrange(lowess_pp, 0, 35) if !missing(lowess_pp)
sort panel ym
format volatility_pp lowess_pp %21.14g
export delimited market_id market month volatility_pp lowess_pp ///
    using "`results'/market-volatility-series.csv", datafmt replace

graph combine `volatility_graphs', cols(3) xcommon ycommon imargin(5pt 6pt 5pt 9pt) iscale(1) ///
    title("{fontface Arial:{bf:Figure 7. Maize price volatility across Kenya}}", `figure_title') ///
    subtitle("Six-month volatility (percentage points) at selected NDMA locations, 2008-2014", `figure_subtitle') ///
    note("{it:Notes.} Blue lines show the sample standard deviation of six consecutive monthly maize inflation rates." ///
         "Red lines show the LOWESS fit (bandwidth 0.30). Gaps mark unavailable seven-price windows." ///
         "{it:Source.} NDMA retail prices for local white maize, archived by FEWS NET.", `figure_note') ///
    `figure_size' ysize(8.1)
save_figure "`output'/figure-7-market-volatility"
