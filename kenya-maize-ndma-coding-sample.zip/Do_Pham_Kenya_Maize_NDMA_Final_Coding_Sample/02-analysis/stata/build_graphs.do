* Draw and export the Kenya maize figures in Stata.
* Run from the submission root. Optional paths set the package, figure, and results folders.
version 18.0
clear all
set more off
set scheme stcolor
args project output results
if `"`project'"' == "" local project "."
if `"`output'"' == "" local output "`project'/03-output/figures"
if "`results'" == "" local results "`project'/03-output/results"
capture mkdir "`output'"
capture mkdir "`results'"

local figure_title "pos(11) span size(16pt) color(black) margin(b=5pt)"
local figure_subtitle "pos(11) span size(11pt) color(black) margin(b=7pt)"
local figure_note "span size(9pt) color(black) margin(t=11pt)"
local figure_size "xsize(8.1) graphregion(color(white) margin(14pt 14pt 14pt 14pt))"

program define save_figure
    args name
    graph save "`name'.gph", replace
    local graphics_setting "`c(graphics)'"
    quietly set graphics off
    capture noisily graph export "`name'.pdf", fontface("Arial") fontfacesans("Arial") replace
    local export_rc = _rc
    quietly set graphics `graphics_setting'
    if `export_rc' exit `export_rc'

    // Use Arial for PNG export, then restore the window font.
    quietly gprefs query window
    local window_font "`r(fontface)'"
    if inlist("`window_font'", "", ".") local window_font "default"
    quietly graph set window fontface "Arial"
    capture noisily graph export "`name'.png", width(2300) replace
    local export_rc = _rc
    quietly graph set window fontface "`window_font'"
    if `export_rc' exit `export_rc'
end

// Use an isolated PERSONAL folder for the built-in grmap activation.
local old_personal : sysdir PERSONAL
tempfile activation
local activation = subinstr("`activation'", "//", "/", .)
mkdir "`activation'"
sysdir set PERSONAL "`activation'/"
quietly grmap, activate

local outlines "`activation'/outlines.dta"
local vertices "`activation'/vertices.dta"
local places "`activation'/places.dta"
local labels "`activation'/labels.dta"
import delimited "`project'/04-data/geography/map-outline.csv", case(preserve) asdouble clear
sort _ID, stable
save "`outlines'"
import delimited "`project'/04-data/geography/map-polygons.csv", case(preserve) asdouble clear
sort _ID, stable
save "`vertices'"
import delimited "`project'/04-data/geography/map-points.csv", asdouble clear
isid market_id
assert _N == 23
label define coordinate 0 "Archive coordinates (19)" 1 "County proxy (4)"
label values coordinate_source coordinate
save "`places'"
import delimited "`project'/04-data/geography/map-labels.csv", asdouble clear
save "`labels'"
import delimited "`project'/04-data/geography/map-regions.csv", asdouble clear
isid map_id, sort
label define groups 0 "Unlinked" 1 "1" 2 "2-3" 3 "4 or more"
label values origin_group groups

grmap using "`vertices'", id(map_id) ///
    fcolor("243 245 246") ocolor("186 196 204") osize(vthin) legenda(off) ///
    line(data("`outlines'") color("34 61 87") size(thin)) ///
    point(data("`places'") xcoord(x) ycoord(y) by(coordinate_source) ///
          shape(O Dh) size(vsmall small) fcolor("34 61 87" white) ocolor("34 61 87" "179 91 32") ///
          osize(vthin thin) legenda(on)) ///
    label(data("`labels'") xcoord(x) ycoord(y) label(area) size(9pt) color(black)) ///
    legend(rows(1) ring(1) position(6) size(10pt) region(lcolor(none))) ///
    title("{fontface Arial:{bf:A.} NDMA reporting locations}", size(12pt) color(black)) ///
    graphregion(color(white)) name(locations, replace) nodraw

grmap origin_group using "`vertices'", id(map_id) ///
    clmethod(unique) fcolor("243 245 246" "232 243 238" "167 207 190" "70 123 104") ///
    ocolor("186 196 204" "117 150 133" "96 131 115" "78 122 105") osize(vthin ..) ///
    line(data("`outlines'") color("34 61 87") size(thin)) ///
    label(data("`labels'") xcoord(x) ycoord(y) label(area) size(9pt) ///
          select(keep if inlist(area,"Uganda","Tanzania","150 km")) color(black)) ///
    legend(rows(1) ring(1) position(6) size(10pt) region(lcolor(none))) ///
    title("{fontface Arial:{bf:B.} Matched maize-growing areas}", size(12pt) color(black)) ///
    graphregion(color(white)) name(origins, replace) nodraw

graph combine locations origins, cols(2) imargin(tiny) ///
    title("{fontface Arial:{bf:Figure 1. Kenya NDMA price coverage and maize supply geography}}", `figure_title') ///
    note("Diamonds indicate county proxies for Baringo, Kilifi, Makueni and Samburu." ///
         "Shading counts the catchments linked to each growing area, including two origins in Tanzania." ///
         "Sources. FEWS NET NDMA prices and trade maps, the study crosswalk, and geoBoundaries.", `figure_note') ///
    `figure_size' ysize(6.8)
save_figure "`output'/figure-1-kenya-map"

erase "`activation'/grmap__activated.ado"
foreach file in outlines vertices places labels {
    erase "``file''"
}
sysdir set PERSONAL "`old_personal'"
capture rmdir "`activation'"

// Figure 2. The unit of each summary is a calendar month.
import delimited "`project'/04-data/observed/ndma-market-month-panel.csv", asdouble clear
generate int ym = monthly(month, "YM")
isid market_id ym, sort
assert _N == 1932
count if !missing(white_maize_retail_kes_per_kg)
assert r(N) == 1930
assert market == "Narok" & inlist(month, "2010-11", "2010-12") if missing(white_maize_retail_kes_per_kg)
preserve
format ym %tmCCYY
rename white_maize_retail_kes_per_kg price
rename maize_inflation_pp inflation
rename maize_inflation_volatility_pp volatility
collapse (p25) lo_price=price lo_inflation=inflation lo_volatility=volatility ///
         (median) center_price=price center_inflation=inflation center_volatility=volatility ///
         (p75) hi_price=price hi_inflation=inflation hi_volatility=volatility, by(ym)
sort ym
assert _N == 84
assert ym == tm(2008m1) + _n - 1

program define plot_series
    args measure heading units ticks
    local first = tm(2008m1)
    local last = tm(2014m12)
    local last_jan = tm(2014m1)
    local years "`first'(12)`last_jan'"
    local time_axis xlabel(`years', nolabels noticks nogrid) xscale(noline)
    if "`measure'" == "volatility" {
        local time_axis xlabel(`years', format(%tmCCYY) labsize(9pt) ///
            labcolor(black) nogrid tlength(tiny) tlcolor(gs8)) xscale(lcolor(gs8) lwidth(vthin))
    }

    local zero
    if "`measure'" == "inflation" local zero yline(0, lcolor(gs9) lpattern(dash) lwidth(thin))
    twoway (rarea lo_`measure' hi_`measure' ym, sort cmissing(n) fcolor("220 232 240") lcolor("220 232 240") fintensity(100)) ///
           (line center_`measure' ym, cmissing(n) lcolor("31 53 73") lwidth(medium)), ///
        `time_axis' xscale(range(`first' `last')) `zero' ///
        ylabel(`ticks', labelminlen(4) angle(horizontal) labsize(9pt) labcolor(black) ///
            noticks grid glcolor(gs14) glpattern(solid) glwidth(vthin)) ///
        yscale(noline) xtitle("") ytitle("`units'", size(10pt) color(black)) ///
        title("{fontface Arial:`heading'}", pos(11) size(12pt) color(black) margin(b=1.4)) ///
        legend(off) graphregion(color(white)) plotregion(lcolor(none) margin(l=1 r=1 t=1 b=1)) ///
        name(`measure', replace) nodraw
end

plot_series price "{bf:A.} Retail price" "KES per kg" "20(20)60"
plot_series inflation "{bf:B.} Monthly price inflation" "Log points" "-30(15)30"
plot_series volatility "{bf:C.} Six-month inflation volatility" "Log points" "0(10)30"
graph combine price inflation volatility, cols(1) xcommon imargin(1.25 1 1.0 .45) iscale(1) ///
    title("{fontface Arial:{bf:Figure 2. Observed retail maize price dynamics, 2008-2014}}", ///
        `figure_title') ///
    subtitle("Monthly median (line) and interquartile range (shading) across reporting locations", ///
        `figure_subtitle') ///
    note("{it:Notes.} Inflation is 100 times the monthly log price change. Volatility is the sample" ///
         "standard deviation of six consecutive inflation rates. Monthly summaries use available data." ///
         "{it:Source.} Kenya NDMA retail prices for local white maize, archived by FEWS NET.", ///
        `figure_note') ///
    `figure_size' ysize(8.4)
save_figure "`output'/figure-2-observed-prices"
restore

// Figures 3 and 5 use the same layout and coefficient scales.
// In each comparison, alternative = 0 is the filled circle.
program define plot_weather
    args weather outcome heading graphname
    if "`weather'" == "rainfall" {
        local categories 1 "Harvest excess" 2 "Harvest shortfall" 4 "Growing excess" ///
                         5 "Growing shortfall" 7 "Planting excess" 8 "Planting shortfall"
        local ticks "-3(1.5)3"
        local limit 3
        local unit "pp per 50 mm"
    }
    else {
        local categories 1 "Harvest warmer" 2 "Harvest cooler" 4 "Growing warmer" ///
                         5 "Growing cooler" 7 "Planting warmer" 8 "Planting cooler"
        local ticks "-12(6)12"
        local limit 13
        local unit "pp per 1°C"
    }
    preserve
    keep if weather == "`weather'" & outcome == "`outcome'"
    isid phase direction alternative
    assert _N == 12
    // Fixed scales put zero at the same position and contain every interval.
    assert ci_low_pp >= -`limit' & ci_high_pp <= `limit'

    twoway (rcap ci_low_pp ci_high_pp position if !alternative, ///
                horizontal lcolor("31 53 73") lwidth(.6pt) msize(2pt)) ///
           (rcap ci_low_pp ci_high_pp position if alternative, ///
                horizontal lcolor("63 113 113") lwidth(.6pt) msize(2pt)) ///
           (scatter position estimate_pp if !alternative, ///
                msymbol(O) mcolor("31 53 73") msize(.73)) ///
           (scatter position estimate_pp if alternative, ///
                msymbol(D) mfcolor(white) mlcolor("63 113 113") mlwidth(vthin) msize(.73)), ///
        xscale(range(-`limit' `limit') lcolor(gs8) lwidth(vthin)) ///
        xlabel(`ticks', labsize(9pt) labcolor(black) nogrid tlength(tiny) tlcolor(gs8)) ///
        xline(0, lcolor(gs9) lpattern(dash) lwidth(thin)) ///
        yline(3 6, lcolor(gs14) lpattern(solid) lwidth(vthin)) ///
        yscale(range(.45 8.55) noline) ///
        ylabel(`categories', angle(horizontal) labsize(9pt) labcolor(black) noticks nogrid) ///
        title("{fontface Arial:`heading'}", span pos(11) size(12pt) color(black) margin(b=1.5)) ///
        xtitle("`unit'", size(10pt) color(black) margin(t=1)) ytitle("") ///
        legend(off) graphregion(color(white)) plotregion(lcolor(none) margin(l=1 r=1 t=0 b=0)) ///
        name(`graphname', replace) nodraw
    restore
end

program define coefficient_panels
    args primary comparison
    generate double position = coefficient_row + cond(alternative, -.22, .22)
    plot_weather rainfall inflation "{bf:A.} Rainfall and inflation" rain_inf
    plot_weather rainfall volatility "{bf:B.} Rainfall and volatility" rain_vol
    plot_weather temperature inflation "{bf:C.} Temperature and inflation" temp_inf
    plot_weather temperature volatility "{bf:D.} Temperature and volatility" temp_vol
    drop position

    // A shared legend strip uses the same markers as all four panels.
    twoway (scatteri 0 0, msymbol(O) mcolor("31 53 73") msize(.73)) ///
           (scatteri 0 0, msymbol(D) mfcolor(white) mlcolor("63 113 113") mlwidth(vthin) msize(.73)), ///
        xscale(off range(-1 1)) yscale(off range(-1 1)) xlabel(none, nogrid) ylabel(none, nogrid) ///
        legend(order(1 "`primary'" 2 "`comparison'") rows(1) size(10pt) ///
            pos(0) ring(0) keygap(1) colgap(3) region(fcolor(white) lcolor(none))) ///
        graphregion(color(white) margin(zero)) plotregion(lcolor(none) margin(zero)) ///
        fysize(6) name(weather_key, replace) nodraw
    graph combine rain_inf rain_vol temp_inf temp_vol, cols(2) imargin(1.25 1.25 1.3 1.3) ///
        iscale(1) graphregion(color(white) margin(zero)) name(weather_panels, replace) nodraw
end

// Keep the validated price panel in the default frame for Figures 4 and 7.
frame create plot_inputs
frame change plot_inputs
import delimited "`results'/crop-phase-results.csv", asdouble clear
isid model outcome rainfall_source phase weather direction
assert inlist(phase, "plant", "grow", "harvest")
assert inlist(direction, "deficit", "excess")
assert !missing(ci_low_pp, estimate_pp, ci_high_pp)
assert ci_low_pp <= estimate_pp & estimate_pp <= ci_high_pp

// Planting at the top. Leave one empty row between successive phases.
generate byte coefficient_row = 1 if phase == "harvest"
replace coefficient_row = 4 if phase == "grow"
replace coefficient_row = 7 if phase == "plant"
replace coefficient_row = coefficient_row + 1 if direction == "deficit"

preserve
    keep if model == "static"
    assert _N == 48
    assert inlist(rainfall_source, "ERA5", "CHIRPS")
    generate byte alternative = rainfall_source == "CHIRPS"
    coefficient_panels "ERA5 rainfall (main)" "CHIRPS rainfall (check)"
    graph combine weather_key weather_panels, cols(1) imargin(zero) iscale(1) ///
        title("{fontface Arial:{bf:Figure 3. Crop-phase weather and maize price outcomes}}", ///
            `figure_title') ///
        subtitle("Static estimates across 23 locations with alternative rainfall measures", ///
            `figure_subtitle') ///
        note("{it:Notes.} Coefficients are in percentage points (pp) per 50 mm or 1°C of anomaly." ///
             "Whiskers show pointwise 95% confidence intervals (calendar HAC with 12 lags)." ///
             "Both models use ERA5 temperature and market and year-month fixed effects.", `figure_note') ///
        `figure_size' ysize(7.9)
    save_figure "`output'/figure-3-weather-coefficients"
restore

// Figure 5. Use the same outcome-specific observations for each model pair.
keep if rainfall_source == "ERA5" & inlist(model, "static_matched", "dynamic")
assert _N == 48
bysort outcome: assert n_obs == n_obs[1]
assert n_obs == 1882 if outcome == "inflation"
assert n_obs == 1762 if outcome == "volatility"
generate byte alternative = model == "dynamic"
coefficient_panels "Static, matched sample" "Dynamic, matched sample"
graph combine weather_key weather_panels, cols(1) imargin(zero) iscale(1) ///
    title("{fontface Arial:{bf:Figure 5. Static and dynamic weather estimates}}", ///
        `figure_title') ///
    subtitle("ERA5 models on identical samples within each outcome", ///
        `figure_subtitle') ///
    note("{it:Notes.} The dynamic model adds a one-month outcome lag. Both models use market and" ///
         "year-month fixed effects. N = 1,882 for inflation and 1,762 for volatility." ///
         "Whiskers show pointwise 95% confidence intervals in percentage points (pp), calendar HAC (12 lags).", ///
        `figure_note') ///
    `figure_size' ysize(7.9)
save_figure "`output'/figure-5-matched-weather-coefficients"

// Figure 4. Summarize the signed ERA5 exposures assigned to location-months.
frame change default
preserve
keep market_id month *_rain_mm *_temp_c
foreach phase in plant grow harvest {
    rename `phase'_rain_mm rain_`phase'
    rename `phase'_temp_c temp_`phase'
}
reshape long rain_ temp_, i(market_id month) j(phase) string
assert !missing(rain_, temp_)
generate byte phase_row = 1 if phase == "harvest"
replace phase_row = 2 if phase == "grow"
replace phase_row = 3 if phase == "plant"
assert !missing(phase_row)

collapse (p5) p05_rain=rain_ p05_temp=temp_ ///
         (p25) p25_rain=rain_ p25_temp=temp_ ///
         (median) p50_rain=rain_ p50_temp=temp_ ///
         (p75) p75_rain=rain_ p75_temp=temp_ ///
         (p95) p95_rain=rain_ p95_temp=temp_, by(phase_row)
assert _N == 3

program define plot_exposure
    args measure heading unit ticks tick_format
    twoway (rspike p05_`measure' p95_`measure' phase_row, ///
                horizontal lcolor("87 108 126") lwidth(medthin)) ///
           (rbar p25_`measure' p75_`measure' phase_row, ///
                horizontal barwidth(.34) fcolor("220 232 240") lcolor("109 141 162") lwidth(vthin)) ///
           (scatter phase_row p50_`measure', msymbol(D) mcolor("31 53 73") msize(small)), ///
        xscale(lcolor(gs8) lwidth(vthin)) ///
        xlabel(`ticks', format(`tick_format') labsize(9pt) labcolor(black) nogrid tlength(tiny) tlcolor(gs8)) ///
        xline(0, lcolor(gs9) lpattern(dash) lwidth(thin)) ///
        yscale(range(.5 3.5) noline) ///
        ylabel(1 "Harvest" 2 "Growing" 3 "Planting", angle(horizontal) labsize(9pt) ///
            labcolor(black) noticks nogrid) ///
        title("{fontface Arial:`heading'}", span pos(11) size(12pt) color(black) margin(b=1.5)) ///
        xtitle("`unit'", size(10pt) color(black) margin(t=1)) ytitle("") ///
        legend(off) graphregion(color(white)) plotregion(lcolor(none) margin(l=1 r=1 t=0 b=0)) ///
        name(exposure_`measure', replace) nodraw
end

plot_exposure rain "{bf:A.} Rainfall" "Rainfall anomaly (mm)" "-300(150)300" "%4.0f"
plot_exposure temp "{bf:B.} Temperature" "Temperature anomaly (°C)" "-1(.5)1" "%4.1f"
graph combine exposure_rain exposure_temp, cols(2) imargin(1.25 1.25 1.3 1.3) iscale(1) ///
    title("{fontface Arial:{bf:Figure 4. Weather anomalies by maize crop phase}}", ///
        `figure_title') ///
    subtitle("ERA5 weather exposures across 1,932 location-months, 2008-2014", ///
        `figure_subtitle') ///
    note("{it:Notes.} Diamonds mark medians, boxes span the middle 50%, and whiskers span the 5th to 95th" ///
         "percentiles. Each location-month uses the latest completed occurrence of each phase." ///
         "Anomalies use the seasonal and trend fit estimated over 1981-2005.", ///
        `figure_note') ///
    `figure_size' ysize(5.8)
save_figure "`output'/figure-4-weather-exposures"
restore

include "`project'/02-analysis/stata/build_location_graphs.do"
frame drop plot_inputs
