"""Build monthly weather anomalies and crop-phase exposures for the NDMA panel."""
import numpy as np
import pandas as pd

PHASES = ("plant", "grow", "harvest")
VARIABLES = ("rain_mm", "temp_c", "chirps_mm")
BASELINE_START = 1981
BASELINE_END = 2005


def anomalies(geo):
    midpoint = (BASELINE_START + BASELINE_END) / 2
    frames = []
    for _, group in geo.groupby('origin',sort=False):
        result=group.copy()
        year=group.month.dt.year.to_numpy()
        calmonth=group.month.dt.month.to_numpy()
        base=(year>=BASELINE_START)&(year<=BASELINE_END)
        calendar_effects=(calmonth[:,None]==np.arange(1,13)).astype(float)
        predictors = np.column_stack((calendar_effects, year - midpoint))
        observed=group[list(VARIABLES)].to_numpy()
        coefficients=np.linalg.lstsq(predictors[base],observed[base],rcond=None)[0]
        predicted=predictors@coefficients
        # A linearly extrapolated rainfall normal cannot be negative.
        predicted[:,[0,2]]=np.maximum(predicted[:,[0,2]],0)
        result[[x+'_normal' for x in VARIABLES]]=predicted
        result[[x+'_anomaly' for x in VARIABLES]]=observed-predicted
        normals=(calendar_effects@coefficients[:12]).clip(min=0)
        result[['rain_mm_reference','chirps_mm_reference']]=normals[:,[0,2]]
        frames.append(result)
    return pd.concat(frames,ignore_index=True)


def phase_weather(geo, schedule, price_months):
    if price_months.empty or price_months.hasnans or not (
        price_months.is_unique and price_months.is_monotonic_increasing
    ):
        raise ValueError("Price months must be nonempty, unique, and chronological.")
    calendar_key = ["origin", "season", "phase"]
    if schedule.empty or schedule[calendar_key].isna().any().any():
        raise ValueError("The crop calendar needs an origin, season, and phase for every row.")
    if schedule.duplicated(calendar_key).any():
        raise ValueError("Duplicate (origin, season, phase) crop-calendar rows.")
    if not schedule["phase"].isin(PHASES).all():
        raise ValueError("The crop calendar contains an unknown phase.")
    if not schedule[["start_month", "end_month"]].isin(range(1, 13)).all().all():
        raise ValueError("Crop-calendar start and end months must be integers from 1 to 12.")
    if geo.duplicated(["origin", "month"]).any():
        raise ValueError("Duplicate (origin, month) weather records in phase construction.")

    rows = []
    for origin, calendars in schedule.groupby("origin", sort=False):
        weather = geo.loc[geo.origin.eq(origin)].set_index("month")
        ends = []
        for item in calendars.itertuples():
            start_month, end_month = int(item.start_month), int(item.end_month)
            for year in range(price_months[0].year - 2, price_months[-1].year + 1):
                start = pd.Period(year=year, month=start_month, freq="M")
                end = pd.Period(year=year + int(end_month < start_month), month=end_month, freq="M")
                phases = pd.period_range(start, end, freq="M")
                if not phases.isin(weather.index).all():
                    continue
                measured = weather.loc[phases]
                days = phases.days_in_month.to_numpy()
                rainfall = [measured[v + "_anomaly"].sum() for v in ("rain_mm", "chirps_mm")]
                norms = [measured[v + "_reference"].sum() for v in ("rain_mm", "chirps_mm")]
                temp = np.average(measured["temp_c_anomaly"], weights=days)
                ends.append({
                    "origin": origin, "phase": item.phase, "season": item.season,
                    "phase_start": start, "phase_end": end, "rain_mm": rainfall[0],
                    "temp_c": temp, "chirps_mm": rainfall[1],
                    "rain_pct": 100 * rainfall[0] / norms[0] if norms[0] > 0 else np.nan,
                    "chirps_pct": 100 * rainfall[1] / norms[1] if norms[1] > 0 else np.nan,
                })
        if not ends:
            raise ValueError(f"No complete weather episodes for {origin}.")
        candidate = pd.DataFrame(ends)
        for phase in PHASES:
            subset = candidate.loc[candidate.phase.eq(phase)].sort_values(["phase_end", "phase_start"])
            if subset["phase_end"].duplicated().any():
                raise ValueError(f"Ambiguous end dates for {origin}, {phase}.")
            # The left insertion point excludes phases ending in the price month.
            indices = subset.phase_end.array.searchsorted(price_months, side='left') - 1
            if (indices < 0).any():
                missing_month = price_months[indices < 0][0]
                raise ValueError(f"No completed {phase} phase for {origin} before {missing_month}.")
            chosen = subset.iloc[indices].copy()
            chosen["month"] = price_months
            if not (chosen.phase_end < chosen.month).all():
                raise ValueError(f"A {phase} phase for {origin} ends on or after its price month.")
            rows.append(chosen)
    result = pd.concat(rows, ignore_index=True)
    if result.duplicated(["origin", "month", "phase"]).any():
        raise ValueError("Duplicate (origin, month, phase) records after phase construction.")
    return result


def weighted_exposure(origins, origin_phase, area, weight="equal"):
    if weight not in {"equal", "area", "domestic"}:
        raise ValueError(f"Unknown catchment weighting: {weight!r}.")
    if origins.empty or origins["catchment"].isna().any() or origins["catchment"].str.strip().eq("").any():
        raise ValueError("Catchment definitions must include named catchments.")
    if origins["catchment"].duplicated().any():
        raise ValueError("Duplicate catchment definitions.")
    links = origins[["catchment", "origins"]].assign(origin=origins.origins.str.split("|")).explode("origin")
    if links["origin"].isna().any() or links["origin"].str.strip().eq("").any():
        raise ValueError("Every catchment must list its linked growing origins.")
    link_key = ["catchment", "origin"]
    duplicates = links.loc[links.duplicated(link_key, keep=False), link_key]
    if not duplicates.empty:
        raise ValueError(f"Duplicate (catchment, origin) link: {tuple(duplicates.iloc[0])}.")
    if weight == "domestic":
        foreign = {"Mbale and Kapchorwa", "Iganga", "Tarime", "Arusha", "Kilimanjaro"}
        links = links.loc[~links["origin"].isin(foreign)]
        if links["catchment"].nunique() != len(origins):
            raise ValueError("Domestic weighting leaves at least one catchment without origins.")

    phase_key = ["origin", "month", "phase"]
    if origin_phase[phase_key].isna().any().any():
        raise ValueError("Crop-phase weather must have a complete (origin, month, phase) key.")
    duplicates = origin_phase.loc[origin_phase.duplicated(phase_key, keep=False), phase_key]
    if not duplicates.empty:
        raise ValueError(f"Duplicate (origin, month, phase) weather record: {tuple(duplicates.iloc[0])}.")
    weather = origin_phase.loc[origin_phase["origin"].isin(links["origin"])]
    month_phase = weather[["month", "phase"]].drop_duplicates()
    # With unique keys, this count proves each linked origin has every observed month-phase pair.
    expected_rows = links["origin"].nunique() * len(month_phase)
    if month_phase.empty or len(weather) != expected_rows:
        raise ValueError("Incomplete (origin, month, phase) weather coverage for linked origins.")

    coverage = area[["origin", "mapspam_rainfed_maize_ha"]]
    missing_origins = links.loc[~links["origin"].isin(coverage["origin"]), "origin"].unique()
    if len(missing_origins):
        raise ValueError(f"Missing MapSPAM coverage for linked origins: {', '.join(missing_origins)}.")
    links = links.merge(coverage, on="origin", validate="many_to_one")
    harvested_area = links["mapspam_rainfed_maize_ha"]
    if not np.isfinite(harvested_area).all() or harvested_area.lt(0).any():
        raise ValueError("MapSPAM area must be finite and nonnegative for each linked origin.")
    basis = harvested_area if weight == "area" else pd.Series(1., index=links.index)
    totals = basis.groupby(links["catchment"]).transform("sum")
    if not np.isfinite(totals).all() or totals.le(0).any():
        raise ValueError("Catchment weights require a finite, positive total.")
    links["weight"] = basis / totals

    columns = [*VARIABLES, "rain_pct", "chirps_pct"]
    if not np.isfinite(weather[columns].to_numpy()).all():
        raise ValueError("Crop-phase anomalies must be finite for linked origins.")
    # An origin can have several catchments and several month-phase records.
    merge = links.merge(weather, on="origin", validate="many_to_many")
    merge[columns] = merge[columns].multiply(merge.weight, axis=0)
    grouped = merge.groupby(["catchment", "month", "phase"])[columns].sum()
    wide = grouped.unstack("phase")
    wide.columns = [f"{phase}_{variable}" for variable, phase in wide.columns]
    return wide.reset_index(), links
