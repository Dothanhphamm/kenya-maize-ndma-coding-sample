"""Convert archived GeoJSON boundaries and reporting locations to Stata map inputs."""

import csv
import json
from pathlib import Path

import pandas as pd
from pyproj import CRS, Transformer
from shapely import make_valid
from shapely.geometry import box, shape
from shapely.ops import transform, unary_union

ROOT = Path(__file__).resolve().parents[2]
PANEL = ROOT / "04-data" / "observed"
BOUNDARIES = ROOT.parent / "kenya-maize-weather-data" / "sources"
TARGET = ROOT / "04-data" / "geography"


def counties(path):
    features = json.loads(path.read_text())["features"]
    return {f["properties"]["shapeName"]: make_valid(shape(f["geometry"])) for f in features}


def polygon_parts(geometry):
    if geometry.geom_type == "Polygon":
        yield geometry
    elif hasattr(geometry, "geoms"):
        for part in geometry.geoms:
            yield from polygon_parts(part)


def write_csv(name, columns, rows):
    with (TARGET / name).open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(columns)
        writer.writerows(rows)


def main():
    TARGET.mkdir(exist_ok=True)
    kenya = counties(BOUNDARIES / "KEN-ADM1.geojson")
    kenya["Tharaka Nithi"] = kenya.pop("Tharaka")
    tanzania = counties(BOUNDARIES / "TZA-ADM1.geojson")
    uganda = counties(BOUNDARIES / "UGA-ADM1.geojson")
    national = unary_union(list(kenya.values()))
    across_border = {k: tanzania[k] for k in ("Arusha", "Kilimanjaro")}
    linked_areas = pd.read_csv(PANEL / "catchment-origin-weights.csv").groupby("origin")["catchment"].nunique()
    if len(linked_areas) != 24 or set(linked_areas.index) - (set(kenya) | set(across_border)):
        raise ValueError("Map inputs must define polygons for all 24 linked growing areas.")
    projection = CRS.from_proj4("+proj=laea +lat_0=0.3 +lon_0=37.8 +datum=WGS84 +units=m")
    project = Transformer.from_crs("EPSG:4326", projection, always_xy=True).transform

    def km(lon, lat):
        x, y = project(lon, lat)
        return x / 1000, y / 1000

    def projected(geometry):
        return transform(km, geometry.simplify(.008, preserve_topology=True))

    area = projected(national)
    min_x, min_y, max_x, max_y = area.bounds
    viewport = box(min_x - 65, min_y - 55, max_x + 55, max_y + 27)
    tc = unary_union(list(tanzania.values())).difference(unary_union(list(across_border.values())))
    backgrounds = {"Uganda": unary_union(list(uganda.values())), "Tanzania": tc}
    polygons = {**backgrounds, **kenya, **across_border}
    region_rows = []
    rings = []
    for index, (name, geometry) in enumerate(polygons.items(), start=1):
        count = int(linked_areas.get(name, 0))
        group = 0 if count == 0 else 1 if count == 1 else 2 if count <= 3 else 3
        region_rows.append((index, name, group))
        for part in polygon_parts(projected(geometry).intersection(viewport)):
            rings.append((index, None, None, 0))
            rings.extend((index, x, y, 0) for x, y in part.exterior.coords)
            for hole in part.interiors:
                rings.append((index, None, None, 1))
                rings.extend((index, x, y, 1) for x, y in hole.coords)
    write_csv("map-regions.csv", ["map_id", "area", "origin_group"], region_rows)
    write_csv("map-polygons.csv", ["_ID", "_X", "_Y", "_EMBEDDED"], rings)

    border_lines = []
    for index, part in enumerate(polygon_parts(area), start=1):
        border_lines.append((index, None, None))
        border_lines.extend((index, x, y) for x, y in part.exterior.coords)
    # Add a 150 km scale bar and its two end ticks in projected coordinates.
    scale_x = min_x - 30
    scale_y = min_y - 25
    for points in (
        [(scale_x, scale_y), (scale_x + 150, scale_y)],
        [(scale_x, scale_y - 4), (scale_x, scale_y + 4)],
        [(scale_x + 150, scale_y - 4), (scale_x + 150, scale_y + 4)],
    ):
        index += 1
        border_lines.append((index, None, None))
        border_lines.extend((index, x, y) for x, y in points)
    write_csv("map-outline.csv", ["_ID", "_X", "_Y"], border_lines)

    markers = pd.read_csv(PANEL / "ndma-market-month-panel.csv", usecols=[
        "market_id", "market", "reporting_area", "geography_flag", "longitude", "latitude",
    ]).drop_duplicates()
    if len(markers) != 23 or not markers["market_id"].is_unique:
        raise ValueError("Map inputs must define one marker for each of the 23 NDMA locations.")
    if not markers["geography_flag"].isin([0, 1]).all() or markers["geography_flag"].sum() != 4:
        raise ValueError("Map inputs must identify four NDMA locations with proxy geography.")
    points = []
    labels = [(*km(34.30, 1.75), "Uganda"), (*km(35.8, -4.22), "Tanzania"),
              (scale_x + 75, scale_y + 21, "150 km")]
    offsets = {"Baringo": (-110, -37), "Makueni": (-117, -34), "Samburu": (104, 39), "Kilifi": (93, -32)}
    for row in markers.itertuples(index=False):
        if row.geography_flag:
            point = kenya[row.reporting_area].representative_point()
            x, y = km(point.x, point.y)
            dx, dy = offsets[row.market]
            labels.append((x + dx, y + dy, row.market))
        else:
            x, y = km(row.longitude, row.latitude)
        points.append((row.market_id, row.market, x, y, row.geography_flag))
    write_csv("map-points.csv", ["market_id", "market", "x", "y", "coordinate_source"], points)
    write_csv("map-labels.csv", ["x", "y", "area"], labels)


if __name__ == "__main__":
    main()
