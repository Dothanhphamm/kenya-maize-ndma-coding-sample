"""Build a historical FEWS NET/NDMA panel from archived public inputs."""

from pathlib import Path

import numpy as np
import pandas as pd

from weather import BASELINE_END, BASELINE_START, VARIABLES, anomalies, phase_weather, weighted_exposure

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "04-data" / "sources"
DATA = ROOT / "04-data" / "observed"
MONTHS = pd.period_range("2008-01", "2014-12", freq="M")
PRICE = "white_maize_retail_kes_per_kg"
EXPECTED_GAPS = {("Narok", "2010-11"), ("Narok", "2010-12")}
CRITERIA = {
    "country_code": "KE",
    "product": "Maize Grain (White)",
    "source_organization": "NDMA, Kenya",
    "source_document": "National Drought Management Authority (NDMA), Kenya, Price",
    "collection_status": "Published",
    "price_type": "Retail",
    "product_source": "Local",
    "unit": "kg",
    "currency": "KES",
    "collection_schedule": "Monthly",
}


def load_prices():
    archive = pd.read_csv(SOURCE / "fews-kenya-retail-maize-full.csv.gz", low_memory=False)
    archive["month"] = pd.to_datetime(archive["period_date"]).dt.to_period("M")
    records = archive.loc[archive["month"].isin(MONTHS)].copy()
    for column, value in CRITERIA.items():
        records = records.loc[records[column].eq(value)]
    keep = [
        "market_id", "market", "month", "period_date", "id", "dataseries", "fnid",
        "source_organization", "source_document", "status", "value", "admin_1",
        "admin_2", "latitude", "longitude",
    ]
    prices = records[keep].rename(columns={
        "id": "fews_record_id", "dataseries": "fews_series_id", "value": PRICE,
        "status": "price_status", "admin_1": "archive_admin_1", "admin_2": "archive_admin_2",
    })
    prices["fews_record_id"] = prices["fews_record_id"].astype("Int64")
    prices["fews_series_id"] = prices["fews_series_id"].astype("Int64")
    price_key = ["market_id", "month"]
    if prices[price_key].isna().any().any():
        raise ValueError("NDMA prices must have a market and month on every row.")
    if prices.duplicated(price_key).any():
        raise ValueError("Duplicate NDMA (market_id, month) price records.")
    if len(prices) != 1932 or prices["market_id"].nunique() != 23:
        raise ValueError("The archived NDMA release must have 1,932 rows across 23 markets.")
    if prices["fews_series_id"].isna().any():
        raise ValueError("NDMA price records are missing FEWS NET series IDs.")
    if (
        prices["fews_series_id"].nunique() != prices["market_id"].nunique()
        or not prices.groupby("market_id")["fews_series_id"].nunique().eq(1).all()
    ):
        raise ValueError("Each NDMA market must map to one distinct FEWS NET series.")
    if not prices["price_status"].isin(["Collected", "Not Collected"]).all():
        raise ValueError("Unexpected collection status in NDMA prices.")
    observed = prices["price_status"].eq("Collected")
    values = prices.loc[observed, PRICE]
    if not np.isfinite(values).all() or not values.gt(0).all():
        raise ValueError("Observed NDMA prices must be finite and strictly positive.")
    if prices.loc[~observed, PRICE].notna().any():
        raise ValueError("NDMA records marked Not Collected must have blank prices.")
    gaps = set(prices.loc[~observed, ["market", "month"]].astype(str).itertuples(index=False, name=None))
    if gaps != EXPECTED_GAPS:
        raise ValueError(f"Unexpected NDMA price gaps: {sorted(gaps)}.")
    expected = pd.MultiIndex.from_product(
        [sorted(prices["market_id"].unique()), MONTHS], names=price_key
    )
    if not prices.set_index(price_key).sort_index().index.equals(expected):
        raise ValueError("NDMA prices do not cover the complete market-month calendar.")
    return prices


def prepare_weather(catchment_names):
    catchments = pd.read_csv(SOURCE / "catchments.csv")
    selected = catchments.loc[catchments["catchment"].isin(catchment_names)]
    missing_catchments = set(catchment_names) - set(selected["catchment"])
    if missing_catchments:
        raise ValueError(f"Missing catchment definitions: {sorted(missing_catchments)}.")
    names = selected["origins"].str.split("|").explode()
    if names.isna().any() or names.str.strip().eq("").any():
        raise ValueError("Catchment definitions have missing origin names.")
    origins = set(names)
    calendars = pd.read_csv(SOURCE / "origin-crop-phases.csv")
    calendars = calendars.loc[calendars["origin"].isin(origins)]
    missing_calendars = origins - set(calendars["origin"])
    if missing_calendars:
        raise ValueError(f"Missing crop calendars for linked origins: {sorted(missing_calendars)}.")
    monthly = pd.read_csv(SOURCE / "origin-month-spatial-weather.csv.gz", float_precision="round_trip")
    monthly = monthly.loc[monthly["origin"].isin(origins)].copy()
    monthly["month"] = pd.PeriodIndex(monthly["month"], freq="M")
    if monthly["month"].isna().any():
        raise ValueError("Regional weather records must have a month.")
    monthly = monthly.loc[monthly["month"] <= MONTHS[-1]]
    monthly = monthly.sort_values(["origin", "month"])
    if monthly.duplicated(["origin", "month"]).any():
        raise ValueError("Duplicate (origin, month) regional weather records.")
    if not np.isfinite(monthly[list(VARIABLES)].to_numpy()).all():
        raise ValueError("Regional weather must have finite rainfall and temperature values.")
    weather_months = pd.period_range(f"{BASELINE_START}-01", MONTHS[-1], freq="M")
    expected = pd.MultiIndex.from_product([sorted(origins), weather_months], names=["origin", "month"])
    missing_weather = expected.difference(monthly.set_index(["origin", "month"]).index)
    if len(missing_weather):
        raise ValueError(f"Missing regional weather for (origin, month): {missing_weather[0]}.")

    monthly_weather = anomalies(monthly)
    phases = phase_weather(monthly_weather, calendars, MONTHS)
    area = pd.read_csv(SOURCE / "origin-grid-coverage.csv")
    exposure, weights = weighted_exposure(selected, phases, area)
    weights.insert(0, "weighting", "equal")
    monthly_weather.to_csv(DATA / "origin-month-weather-anomalies.csv", index=False, float_format="%.16g")
    phases.sort_values(["origin", "month", "phase"]).to_csv(
        DATA / "origin-most-recent-crop-phase.csv", index=False, float_format="%.15g"
    )
    weights.sort_values(["catchment", "origin"]).to_csv(
        DATA / "catchment-origin-weights.csv", index=False, float_format="%.15g"
    )
    return exposure


def main():
    DATA.mkdir(exist_ok=True)
    prices = load_prices()
    crosswalk = pd.read_csv(SOURCE / "historical-catchments.csv")
    if len(crosswalk) != 23 or not crosswalk["market_id"].is_unique or crosswalk["catchment"].isna().any():
        raise ValueError("The market crosswalk needs one named catchment for each of the 23 NDMA markets.")
    if set(zip(prices["market_id"], prices["market"])) != set(zip(crosswalk["market_id"], crosswalk["market"])):
        raise ValueError("The market IDs and names in the crosswalk do not match the NDMA price archive.")
    panel = prices.merge(crosswalk.drop(columns="basis"), on=["market_id", "market"], validate="many_to_one")
    exposure = prepare_weather(crosswalk["catchment"].unique())
    panel = panel.merge(exposure, on=["catchment", "month"], validate="many_to_one", how="left", indicator=True)
    if not panel.pop("_merge").eq("both").all():
        raise ValueError("At least one NDMA market-month is missing its catchment exposure.")
    panel = panel.sort_values(["market_id", "month"])
    panel["log_price"] = np.log(panel[PRICE])
    panel["maize_inflation_pp"] = 100 * panel.groupby("market_id")["log_price"].diff()
    panel["maize_inflation_volatility_pp"] = panel.groupby("market_id")["maize_inflation_pp"].transform(
        lambda changes: changes.rolling(6, min_periods=6).std(ddof=1)
    )
    panel = panel.drop(columns="log_price")
    if panel["maize_inflation_pp"].count() != 1906 or panel["maize_inflation_volatility_pp"].count() != 1786:
        raise ValueError("The archived panel should yield 1,906 inflation and 1,786 volatility windows.")
    panel.to_csv(DATA / "ndma-market-month-panel.csv", index=False, float_format="%.16g")
    panel.loc[panel[PRICE].notna()].to_csv(
        DATA / "ndma-observed-price-panel.csv", index=False, float_format="%.16g"
    )
    panel.loc[panel[PRICE].isna(), [
        "market_id", "market", "month", "fews_series_id", "fews_record_id", "price_status"
    ]].to_csv(DATA / "missing-market-months.csv", index=False)
    print("Verified 1,930 NDMA prices and two gaps on a unique 1,932-row calendar grid.")
    print(f"Constructed crop-phase exposures from the {BASELINE_START}–{BASELINE_END} weather baseline.")


if __name__ == "__main__":
    main()
