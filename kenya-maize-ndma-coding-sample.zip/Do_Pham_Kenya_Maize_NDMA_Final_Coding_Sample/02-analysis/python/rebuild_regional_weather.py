"""Reproduce historical growing-area weather from the archived grids."""

from argparse import ArgumentParser
import json
from pathlib import Path

import numpy as np
import pandas as pd

from prepare_ndma_panel import SOURCE, load_prices


def read_features(path):
    return json.loads(path.read_text())['features']


def load_weather(base):
    from netCDF4 import Dataset, num2date

    sources = {
        "era5-east-africa-monthly-1981-2026.nc": (
            ("precipitation", "rain_mm"),
            ("air_temperature_2m", "temp_c"),
        ),
        "chirps-v3-east-africa-monthly-1981-2026.nc": (("precipitation", "chirps_mm"),),
    }
    months = None
    grids = []
    for filename, variables in sources.items():
        with Dataset(base / filename) as ds:
            time = ds["time"]
            dates = num2date(time[:], time.units, time.calendar)
            periods = pd.PeriodIndex([f"{date.year}-{date.month:02}" for date in dates], freq="M")
            if months is None:
                months = periods
            elif not periods.equals(months):
                raise ValueError("ERA5 and CHIRPS gridded inputs have different month indexes.")

            lat = ds["latitude"][:].data
            lon = ds["longitude"][:].data
            values = {name: np.ma.filled(ds[variable][:], np.nan) for variable, name in variables}
            expected_shape = (len(periods), len(lat), len(lon))
            if any(data.shape != expected_shape for data in values.values()):
                raise ValueError(f"Weather values in {filename} must match the time and grid axes.")
            grids.append((lat, lon, values))
    return months, grids


def nearest_grid_indices(axis, coordinates):
    """Find the closest cell centers along one increasing or decreasing axis."""
    centers = np.asarray(axis, dtype=float)
    points = np.asarray(coordinates, dtype=float)
    if centers.ndim != 1 or len(centers) < 2 or not np.isfinite(centers).all():
        raise ValueError("Weather grid axes need at least two finite cell centers.")
    steps = np.diff(centers)
    descending = (steps < 0).all()
    if descending:
        centers = centers[::-1]
    elif not (steps > 0).all():
        raise ValueError("Weather grid cell centers must be strictly monotonic.")

    lower_edge = centers[0] - (centers[1] - centers[0]) / 2
    upper_edge = centers[-1] + (centers[-1] - centers[-2]) / 2
    if not np.isfinite(points).all() or (points < lower_edge).any() or (points > upper_edge).any():
        raise ValueError("MapSPAM cells extend outside the weather grid.")

    right = np.searchsorted(centers, points).clip(1, len(centers) - 1)
    left = right - 1
    nearest = np.where(np.abs(points - centers[left]) <= np.abs(points - centers[right]), left, right)
    return len(centers) - 1 - nearest if descending else nearest


def grid_weights(lat, lon, xs, ys, harvested_area):
    """Sum the harvested area of crop cells that map to each weather grid cell."""
    grid_x = nearest_grid_indices(lon, xs)
    grid_y = nearest_grid_indices(lat, ys)
    indices, inverse = np.unique(grid_y * len(lon) + grid_x, return_inverse=True)
    return indices, np.bincount(inverse, weights=harvested_area)


def average_grid_weather(data, indices, weights):
    values = data.reshape(len(data), -1)[:, indices]
    coverage = np.sum(np.isfinite(values) * weights, axis=1)
    total_weight = weights.sum()
    minimum_coverage = coverage.min()
    if minimum_coverage < .90 * total_weight:
        raise ValueError("Weather coverage falls below 90% of MapSPAM weight in at least one month.")
    return np.nansum(values * weights, axis=1) / coverage, float(minimum_coverage / total_weight)


def spatial_series(base, geometry, used):
    import rasterio
    from shapely import contains_xy

    months, grids = load_weather(base)
    with rasterio.open(base / "sources/mapspam-2000-rainfed-maize-harvested-area-east-africa.tif") as src:
        area = src.read(1).astype("f8")
        row, col = np.nonzero(area > 0)
        a, b, c, d, e, f = tuple(src.transform)[:6]
        xs = a * (col + 0.5) + b * (row + 0.5) + c
        ys = d * (col + 0.5) + e * (row + 0.5) + f
        harvested_area = area[row, col]
    frames, metadata = [], []
    for origin in sorted(used):
        hit = contains_xy(geometry[origin], xs, ys)
        if not hit.any():
            raise ValueError(f"No positive MapSPAM cells fall inside {origin}.")
        origin_x, origin_y, origin_area = xs[hit], ys[hit], harvested_area[hit]
        entry = {
            "origin": origin,
            "mapspam_rainfed_maize_ha": origin_area.sum(),
            "crop_grid_cells": len(origin_area),
        }
        averages = {}
        # ERA5 rainfall and temperature share a grid. Coverage is variable-specific.
        for lat, lon, values in grids:
            indices, weights = grid_weights(lat, lon, origin_x, origin_y, origin_area)
            for variable, data in values.items():
                averages[variable], coverage = average_grid_weather(data, indices, weights)
                entry[f"{variable}_minimum_weight_coverage"] = coverage
        frames.append(pd.DataFrame({"origin": origin, "month": months, **averages}))
        metadata.append(entry)
    return pd.concat(frames, ignore_index=True), pd.DataFrame(metadata)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("weather_archive", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from shapely import make_valid
    from shapely.geometry import Point, shape

    base = args.weather_archive
    geography = {
        feature["properties"]["shapeName"]: make_valid(shape(feature["geometry"]))
        for feature in read_features(base / "sources/KEN-ADM1.geojson")
    }
    geography["Tharaka Nithi"] = geography.pop("Tharaka")

    # Check the coordinates against contemporary county polygons while
    # preserving historical reporting labels in the analysis crosswalk.
    crosswalk = pd.read_csv(SOURCE / "historical-catchments.csv")
    sites = load_prices()[["market_id", "longitude", "latitude"]].drop_duplicates()
    sites = sites.merge(crosswalk, on="market_id", validate="one_to_one")
    for site in sites.itertuples(index=False):
        point = Point(site.longitude, site.latitude)
        matches = [county for county, geometry in geography.items() if geometry.covers(point)]
        if len(matches) > 1:
            raise ValueError(f"Archive coordinates for {site.market} match more than one county.")
        coordinate_county = matches[0] if matches else "Offshore or outside polygon"
        if coordinate_county != site.coordinate_county:
            raise ValueError(f"Coordinate county for {site.market} differs from the archived crosswalk.")
        if (coordinate_county != site.reporting_area) != bool(site.geography_flag):
            raise ValueError(f"Invalid geography flag in the crosswalk for {site.market}.")

    geography.update({
        feature["properties"]["origin"]: make_valid(shape(feature["geometry"]))
        for feature in read_features(SOURCE / "cross-border-origins.geojson")
    })
    geography.update({
        feature["properties"]["shapeName"]: make_valid(shape(feature["geometry"]))
        for feature in read_features(base / "sources/TZA-ADM1.geojson")
        if feature["properties"]["shapeName"] in {"Arusha", "Kilimanjaro"}
    })
    catchments = pd.read_csv(SOURCE / "catchments.csv")
    origins = set(catchments.loc[catchments["catchment"].isin(crosswalk["catchment"]), "origins"]
                  .str.split("|").explode())
    monthly, coverage = spatial_series(base, geography, origins)

    # Verify both spatial inputs before writing outputs to a separate directory.
    monthly["month"] = monthly["month"].astype(str)
    archived = pd.read_csv(SOURCE / "origin-month-spatial-weather.csv.gz", float_precision="round_trip")
    archived = archived.loc[archived["origin"].isin(origins)]
    key = ["origin", "month"]
    pd.testing.assert_frame_equal(monthly.sort_values(key).reset_index(drop=True),
                                  archived.sort_values(key).reset_index(drop=True),
                                  atol=1e-9, rtol=1e-10)
    archived = pd.read_csv(SOURCE / "origin-grid-coverage.csv", float_precision="round_trip")
    archived = archived.loc[archived["origin"].isin(origins)]
    pd.testing.assert_frame_equal(coverage.sort_values("origin").reset_index(drop=True),
                                  archived.sort_values("origin").reset_index(drop=True),
                                  atol=1e-9, rtol=1e-10)
    args.output.mkdir(parents=True, exist_ok=True)
    monthly.to_csv(args.output / "origin-month-spatial-weather.csv.gz", index=False,
                   float_format="%.17g", compression={"method": "gzip", "mtime": 0})
    coverage.to_csv(args.output / "origin-grid-coverage.csv", index=False, float_format="%.17g")
    print(f"Rebuilt and verified spatial weather inputs for {len(origins)} supply origins.")


if __name__ == "__main__":
    main()
