"""Write paper-style tables and editable LaTeX from the observed panel and Stata."""

from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Table, TableStyle

from pdf_fonts import DEFAULT_FONT_DIR, find_font

PHASES = {"plant": "Planting", "grow": "Growing", "harvest": "Harvest"}
MEASURES = {
    ("rainfall", "deficit"): "Rainfall shortfall (50 mm)",
    ("rainfall", "excess"): "Rainfall excess (50 mm)",
    ("temperature", "deficit"): "Cool deviation (1 °C)",
    ("temperature", "excess"): "Warm deviation (1 °C)",
}
STATIC = [
    ("inflation", "static", "ERA5"),
    ("inflation", "static", "CHIRPS"),
    ("volatility", "static", "ERA5"),
    ("volatility", "static", "CHIRPS"),
]
MATCHED = [("static_matched", "ERA5"), ("dynamic", "ERA5"),
           ("static_matched", "CHIRPS"), ("dynamic", "CHIRPS")]


def summary_table(panel):
    rows = [("section", "Prices and outcomes", [])]
    names = {
        "white_maize_retail_kes_per_kg": "Retail white maize price (KES/kg)",
        "maize_inflation_pp": "Monthly log price change (pp)",
        "maize_inflation_volatility_pp": "Six-month inflation volatility (pp)",
    }
    groups = [("", names)]
    for phase, name in PHASES.items():
        groups.append((name + " weather anomalies", {
            f"{phase}_rain_mm": "ERA5 rainfall (mm)",
            f"{phase}_chirps_mm": "CHIRPS rainfall (mm)",
            f"{phase}_temp_c": "ERA5 temperature (°C)",
        }))
    for section, variables in groups:
        if section:
            rows.append(("section", section, []))
        for variable, label in variables.items():
            data = panel[variable].dropna()
            statistics = [data.mean(), data.std(), *data.quantile([.25, .5, .75])]
            values = [f"{len(data):,}", *(f"{v:,.2f}" for v in statistics)]
            rows.append(("data", label, values))
    return (
        "Table 1. Descriptive statistics",
        ["Variable", "N", "Mean", "SD", "P25", "Median", "P75"], rows,
        f"The calendar spine contains {len(panel):,} location-months "
        f"across {panel['market_id'].nunique():,} NDMA reporting locations, "
        "January 2008 to December 2014. The price and outcome rows use available observations "
        "for each variable. Weather rows report signed phase anomalies relative to the 1981-2005 "
        "reference fit. Each available location-month has equal weight.",
    )


def coefficient_cell(estimate, se, p):
    stars = "***" if p < .01 else "**" if p < .05 else "*" if p < .10 else ""
    return f"{estimate:.3f}{stars}", f"({se:.3f})"


def model_table(title, labels, specs, estimates, fits, lags):
    results = []
    for phase, name in PHASES.items():
        results.append(("section", name, []))
        for (weather, direction), term in MEASURES.items():
            data = [estimates.loc[(*spec, phase, weather, direction)] for spec in specs]
            values = [coefficient_cell(row.estimate_pp, row.se_pp, row.p) for row in data]
            results.append(("data", term, values))
    dynamic = any(model == "dynamic" for _, model, _ in specs)
    if dynamic:
        values = []
        for spec in specs:
            if spec[1] == "dynamic":
                data = lags.loc[spec]
                values.append(coefficient_cell(data.coef, data.se, data.p))
            else:
                values.append("")
        results.append(("section", "Outcome persistence", []))
        results.append(("data", "Lagged outcome", values))
    diagnostics = [fits.loc[spec] for spec in specs]
    results.append(("section", "Model fit", []))
    results.append(("data", "Observations", [f"{row.n_obs:,}" for row in diagnostics]))
    results.append(("data", "Reporting locations", [str(row.markets) for row in diagnostics]))
    results.append(("data", "Reduction in MSE (%)", [f"{row.mse_reduction_pct:.2f}" for row in diagnostics]))
    results.append(("data", "Joint weather test (p)",
                    ["<0.001" if row.weather_p < .001 else f"{row.weather_p:.3f}" for row in diagnostics]))
    notes = (
        "Each specification includes location and year-month fixed effects. Both rainfall specifications "
        "use ERA5 temperature. Coefficients are in percentage points per indicated weather change. "
        "Parentheses give 12-month Bartlett calendar HAC standard errors. "
        "* p < 0.10, ** p < 0.05, *** p < 0.01, pointwise. "
        "MSE reduction compares each model with its weather-free counterpart on the same sample."
    )
    if not dynamic:
        notes += " Static ERA5 is the main specification."
    if dynamic:
        notes += " Static and dynamic columns use the same location-months. Dynamic models add one outcome lag."
    return title, ["Weather change", *labels], results, notes


def create_tables(panel, phase, fit, coef):
    estimates = phase.set_index(["outcome", "model", "rainfall_source", "phase", "weather", "direction"])
    fits = fit.loc[fit["sample"].eq("all_markets")].assign(rainfall_source=lambda f: f.rainfall.str.upper())
    fits = fits.set_index(["outcome", "model", "rainfall_source"])
    lags = coef.loc[coef["sample"].eq("all_markets") & coef.term.str.startswith("lag_")].copy()
    lags["rainfall_source"] = lags.rainfall.str.upper()
    lags = lags.set_index(["outcome", "model", "rainfall_source"])
    if len(estimates) != 144 or not estimates.index.is_unique:
        raise ValueError("Paper tables require 144 distinct full-sample phase coefficients.")
    if len(fits) != 12 or not fits.index.is_unique:
        raise ValueError("Paper tables require one fit per full-sample outcome and specification.")
    if len(lags) != 4 or not lags.index.is_unique:
        raise ValueError("Paper tables require one lag coefficient per full-sample dynamic model.")

    tables = [
        summary_table(panel),
        model_table("Table 2. Static weather regressions",
                    ["Inflation\nERA5", "Inflation\nCHIRPS", "Volatility\nERA5", "Volatility\nCHIRPS"],
                    STATIC, estimates, fits, lags),
    ]
    for number, (outcome, label) in enumerate(
            (("inflation", "monthly inflation"), ("volatility", "inflation volatility")), start=3):
        tables.append(model_table(
            f"Table {number}. Matched static and dynamic models for {label}",
            ["ERA5\nStatic", "ERA5\nDynamic", "CHIRPS\nStatic", "CHIRPS\nDynamic"],
            [(outcome, model, rainfall) for model, rainfall in MATCHED], estimates, fits, lags,
        ))
    return tables


def quote_tex(text):
    replacements = {"%": r"\%", "&": r"\&", "_": r"\_", "<": r"\textless{}",
                    ">": r"\textgreater{}", "°": r"\ensuremath{{}^\circ}"}
    return "".join(replacements.get(char, char) for char in text)


def tex_cell(value):
    if isinstance(value, tuple):
        return r"\shortstack[r]{" + r" \\ ".join(quote_tex(v) for v in value) + "}"
    parts = value.splitlines()
    return r"\shortstack{" + r" \\ ".join(map(quote_tex, parts)) + "}" if len(parts) > 1 else quote_tex(value)


def write_latex(tables, folder):
    for number, (title, headings, rows, note) in enumerate(tables, start=1):
        columns = len(headings)
        rowbreak = " " + chr(92) * 2
        lines = [
            r"% Requires \usepackage{booktabs}",
            r"\begin{table}[htbp]",
            r"\centering",
            r"\caption{" + quote_tex(title.split(". ", maxsplit=1)[1]) + "}",
            r"\label{tab:kenya-maize-" + str(number) + "}",
            r"\small",
            r"\begin{tabular}{l" + "r" * (columns - 1) + "}",
            r"\toprule",
            " & ".join(tex_cell(v) for v in headings) + rowbreak,
            r"\midrule",
        ]
        for kind, label, values in rows:
            if kind == "section":
                lines.append(r"\addlinespace[0.4em]")
                lines.append(r"\multicolumn{" + str(columns) + r"}{l}{\textit{" + quote_tex(label) + "}}" + rowbreak)
            else:
                lines.append(" & ".join([quote_tex(label), *(tex_cell(v) for v in values)]) + rowbreak)
        lines.extend([
            r"\bottomrule", r"\end{tabular}", r"\par\medskip",
            r"\begin{minipage}{0.95\linewidth}",
            r"\footnotesize\textit{Notes.} " + quote_tex(note),
            r"\end{minipage}", r"\end{table}", "",
        ])
        (folder / f"table-{number}.tex").write_text("\n".join(lines))


def draw_table_pages(tables, path: Path, font_dir: Path | None = None):
    directory = DEFAULT_FONT_DIR if font_dir is None else font_dir
    try:
        regular_path = find_font(directory, "Georgia.ttf")
        bold_path = find_font(directory, "Georgia Bold.ttf", "georgiab.ttf")
    except FileNotFoundError:
        if font_dir is not None:
            raise
        regular, bold = "Times-Roman", "Times-Bold"
    else:
        regular, bold = "PaperSerif", "PaperSerifBold"
        pdfmetrics.registerFont(TTFont(regular, str(regular_path)))
        pdfmetrics.registerFont(TTFont(bold, str(bold_path)))
        pdfmetrics.registerFontFamily(regular, normal=regular, bold=bold)
    ink = colors.HexColor("#202A32")
    gray = colors.HexColor("#59646D")
    line = colors.HexColor("#AAB4BD")
    title_style = ParagraphStyle("title", fontName=bold, fontSize=13, leading=17,
                                 textColor=ink, spaceAfter=17)
    cell = ParagraphStyle("label", fontName=regular, fontSize=8.45, leading=10.65, textColor=ink)
    numeric = ParagraphStyle("value", parent=cell, alignment=TA_RIGHT)
    header = ParagraphStyle("header", parent=numeric, fontName=bold)
    first_header = ParagraphStyle("first", parent=cell, fontName=bold)
    note_style = ParagraphStyle("note", parent=cell, fontSize=8.1, leading=11.4, textColor=gray,
                                spaceBefore=8)

    def paragraph(value, style):
        return Paragraph(escape(value).replace("\n", "<br/>"), style)

    story = []
    for index, (title, labels, rows, notes) in enumerate(tables):
        story.append(paragraph(title, title_style))
        n = len(labels)
        first_column = 197 if index == 0 else 170
        width = 516
        widths = [first_column] + [(width - first_column) / (n - 1)] * (n - 1)
        data = [[paragraph(v, first_header if i == 0 else header) for i, v in enumerate(labels)]]
        sections = []
        for kind, label, values in rows:
            if kind == "section":
                sections.append(len(data))
                data.append([paragraph(label, first_header)] + [""] * (n - 1))
            else:
                strings = ["\n".join(v) if isinstance(v, tuple) else v for v in values]
                data.append([paragraph(label, cell), *(paragraph(v, numeric) for v in strings)])
        table = Table(data, colWidths=widths, hAlign="LEFT")
        style = [
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 2.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
            ("LINEABOVE", (0, 0), (-1, 0), .95, ink),
            ("LINEBELOW", (0, 0), (-1, 0), .55, line),
            ("LINEBELOW", (0, -1), (-1, -1), .9, ink),
        ]
        for row in sections:
            style.extend([
                ("SPAN", (0, row), (-1, row)),
                ("TOPPADDING", (0, row), (-1, row), 7),
                ("BOTTOMPADDING", (0, row), (-1, row), 2),
            ])
        table.setStyle(TableStyle(style))
        story.append(table)
        story.append(paragraph("Notes. " + notes, note_style))
        if index < len(tables) - 1:
            story.append(PageBreak())
    doc = SimpleDocTemplate(str(path), pagesize=letter, topMargin=52, bottomMargin=49,
                            leftMargin=42, rightMargin=42)
    doc.build(story)
