"""Export every crop-phase coefficient for the main sample and checks."""

import csv
from decimal import Decimal
from itertools import product
from pathlib import Path

RESULTS = Path(__file__).resolve().parents[2] / "03-output" / "results"
OUTCOMES = ("inflation", "volatility")
MODELS = ("static", "static_matched", "dynamic")
RAINFALL = {"era5": "rain_mm", "chirps": "chirps_mm"}
PHASES = ("plant", "grow", "harvest")
DIRECTIONS = ("deficit", "excess")
COEFFICIENT_FIELDS = {
    "estimate_pp": "coef",
    "se_pp": "se",
    "ci_low_pp": "ci_low",
    "ci_high_pp": "ci_high",
}


def read_main_sample(path, key_fields):
    with path.open(newline="") as stream:
        rows = {}
        for row in csv.DictReader(stream):
            if row["sample"] == "all_markets":
                key = tuple(row[field] for field in key_fields)
                if key in rows:
                    raise ValueError(f"Duplicate result in {path.name}: {key}")
                rows[key] = row
    return rows


def build_table():
    model_key = ("outcome", "model", "rainfall")
    fits = read_main_sample(RESULTS / "model-fit.csv", model_key)
    estimates = read_main_sample(RESULTS / "coefficients.csv", (*model_key, "term"))

    rows = []
    for outcome, model, rainfall in product(OUTCOMES, MODELS, RAINFALL):
        key = (outcome, model, rainfall)
        fit = fits.get(key)
        if fit is None:
            raise ValueError(f"Missing model fit for {key}.")
        role = {
            ("static", "era5"): "Main",
            ("static", "chirps"): "Rainfall check",
        }.get((model, rainfall), "Persistence check")
        for phase, weather, direction in product(PHASES, ("rainfall", "temperature"), DIRECTIONS):
            weather_term = RAINFALL[rainfall] if weather == "rainfall" else "temp_c"
            term = f"{phase}_{weather_term}_{direction}"
            estimate = estimates.get((*key, term))
            if estimate is None:
                raise ValueError(f"Missing coefficient for {(*key, term)}.")
            scale = 50 if weather == "rainfall" else 1
            row = {
                "outcome": outcome,
                "role": role,
                "model": model,
                "rainfall_source": rainfall.upper(),
                "n_obs": fit["n_obs"],
                "phase": phase,
                "weather": weather,
                "direction": direction,
                "change": "50 mm" if weather == "rainfall" else "1 deg C",
                "term": term,
                "p": estimate["p"],
            }
            row.update({
                field: str(Decimal(estimate[source]) * scale)
                for field, source in COEFFICIENT_FIELDS.items()
            })
            rows.append(row)
    with (RESULTS / "crop-phase-results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    build_table()
