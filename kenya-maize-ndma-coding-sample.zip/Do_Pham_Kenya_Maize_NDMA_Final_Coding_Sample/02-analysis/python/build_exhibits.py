"""Format paper tables and combine them with the Stata-rendered figures."""

from argparse import ArgumentParser
from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd
from pypdf import PdfReader, PdfWriter, Transformation

from build_tables import create_tables, draw_table_pages, write_latex
from prepare_ndma_panel import EXPECTED_GAPS, PRICE

ROOT = Path(__file__).resolve().parents[2]
FIGURES = (
    ("figure-1-kenya-map.pdf", "Figure 1. Kenya NDMA price coverage and maize supply geography"),
    ("figure-2-observed-prices.pdf", "Figure 2. Observed retail maize price dynamics"),
    ("figure-3-weather-coefficients.pdf", "Figure 3. Crop-phase weather and maize price outcomes"),
    ("figure-4-weather-exposures.pdf", "Figure 4. Weather anomalies by maize crop phase"),
    ("figure-5-matched-weather-coefficients.pdf", "Figure 5. Static and dynamic weather estimates"),
    ("figure-6a-monthly-rainfall.pdf", "Figure 6a. Monthly rainfall in maize-supplying areas"),
    ("figure-6b-monthly-temperature.pdf", "Figure 6b. Monthly temperature in maize-supplying areas"),
    ("figure-7-market-volatility.pdf", "Figure 7. Maize price volatility across Kenya"),
)


def combine_pdf(figures_dir, table_pages, tables, output):
    writer = PdfWriter()
    for index, (filename, title) in enumerate(FIGURES):
        file = figures_dir / filename
        if not file.is_file():
            raise FileNotFoundError(f"Run build_graphs.do before assembling the PDF: {file}")
        fig_page = PdfReader(file).pages[0]
        width, height = float(fig_page.mediabox.width), float(fig_page.mediabox.height)
        page = writer.add_blank_page(width=612, height=792)
        scale = min((612 - 56) / width, (792 - 70) / height)
        page.merge_transformed_page(fig_page, Transformation().scale(scale).translate(
            tx=(612 - scale * width) / 2, ty=792 - scale * height - 34,
        ))
        writer.add_outline_item(title=title, page_number=index)
    reader = PdfReader(table_pages)
    if len(reader.pages) != len(tables):
        raise RuntimeError("The paper tables did not render one table per page.")
    for number, (page, table) in enumerate(zip(reader.pages, tables), start=len(FIGURES)):
        writer.add_page(page)
        writer.add_outline_item(title=table[0], page_number=number)
    writer.add_metadata({"/Title": "Kenya maize prices and crop-phase weather | Figures and tables"})
    writer.write(output)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=ROOT / "03-output")
    parser.add_argument("--font-dir", type=Path, help="Directory containing the Georgia TrueType files.")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    figures = args.output / "figures"
    tables_dir = args.output / "tables"
    tables_dir.mkdir(exist_ok=True)
    panel = pd.read_csv(args.project / "04-data/observed/ndma-market-month-panel.csv")
    phase = pd.read_csv(args.project / "03-output/results/crop-phase-results.csv")
    fit = pd.read_csv(args.project / "03-output/results/model-fit.csv")
    coefs = pd.read_csv(args.project / "03-output/results/coefficients.csv")
    if len(panel) != 1932 or panel[PRICE].count() != 1930:
        raise ValueError("The archived panel must contain 1,932 location-months and 1,930 observed prices.")
    if panel.duplicated(["market_id", "month"]).any():
        raise ValueError("Duplicate market-months in the panel used for the exhibits.")
    gaps = panel.loc[panel[PRICE].isna(), ["market", "month"]]
    if set(gaps.itertuples(index=False, name=None)) != EXPECTED_GAPS:
        raise ValueError("Unexpected price gaps in the panel used for the exhibits.")

    tables = create_tables(panel, phase, fit, coefs)
    with TemporaryDirectory() as temporary:
        table_pages = Path(temporary) / "tables.pdf"
        try:
            draw_table_pages(tables, table_pages, font_dir=args.font_dir)
        except FileNotFoundError as error:
            parser.error(str(error))
        combine_pdf(figures, table_pages, tables, args.output / "Kenya_Maize_Figures_and_Tables.pdf")
    write_latex(tables, tables_dir)


if __name__ == "__main__":
    main()
