"""Audit original sources for exact retail price matches in Narok."""

import csv
import gzip

from prepare_ndma_panel import ROOT, SOURCE

GAPS = {"2010-11", "2010-12"}


def audit_fews():
    with gzip.open(SOURCE / "fews-kenya-retail-maize-full.csv.gz", "rt", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    candidates = [
        row for row in rows
        if "narok" in (row["market"] + " " + row["admin_1"]).lower()
        and row["period_date"][:7] in GAPS
    ]
    return len(candidates), sum(
        row["status"] == "Collected" and float(row["value"] or 0) > 0
        for row in candidates
    )


def audit_wfp():
    with gzip.open(SOURCE / "audit/wfp-kenya-2008-2014.csv.gz", "rt") as handle:
        retail = [
            row for row in csv.DictReader(handle)
            if row["commodity"] == "Maize (white)" and row["pricetype"] == "Retail"
            and row["priceflag"] == "actual" and row["currency"] == "KES" and row["unit"] == "KG"
            and float(row["price"]) > 0
        ]
    narok = [
        row for row in retail
        if "narok" in " ".join(row[key] for key in ("market", "admin1", "admin2")).lower()
    ]
    return len(retail), len(narok), sum(row["date"][:7] in GAPS for row in narok)


def main():
    fews_rows, fews_prices = audit_fews()
    historical_wfp, narok_wfp, wfp_prices = audit_wfp()
    if (fews_rows, fews_prices, historical_wfp, narok_wfp, wfp_prices) != (2, 0, 331, 0, 0):
        raise ValueError("Narok gap audit does not match the archived FEWS NET and WFP coverage.")
    with (ROOT / "03-output/results/narok-source-audit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["archive", "scope", "rows_checked", "observed_narok_gap_matches"])
        writer.writerow(["FEWS NET", "Narok in November and December 2010", fews_rows, fews_prices])
        writer.writerow(["WFP HDX", "Historical actual white maize retail prices in KES/kg", historical_wfp, wfp_prices])


if __name__ == "__main__":
    main()
