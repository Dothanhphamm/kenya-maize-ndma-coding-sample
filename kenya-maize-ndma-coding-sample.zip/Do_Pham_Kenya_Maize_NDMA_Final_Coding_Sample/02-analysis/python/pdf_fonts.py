"""Locate the TrueType fonts used to render the coding sample."""

from pathlib import Path

DEFAULT_FONT_DIR = Path("/System/Library/Fonts/Supplemental")


def find_font(font_dir, *filenames):
    directory = Path(font_dir).expanduser()
    if directory.is_dir():
        fonts = {path.name.casefold(): path for path in directory.iterdir() if path.is_file()}
        for filename in filenames:
            if filename.casefold() in fonts:
                return fonts[filename.casefold()]
    names = " or ".join(filenames)
    raise FileNotFoundError(f"Could not find {names} in {directory}. Set --font-dir to the font folder.")
