# Weather and retail maize prices in Kenya

**Thanh-Do Pham · Python, Stata, and ArcGIS Pro coding sample · 2008–2014 NDMA panel**

**Research question.** How do rainfall and temperature anomalies during planting, growing, and harvest in maize-supplying regions relate to monthly retail maize price inflation and volatility in Kenya?

## Package layout

```text
README.md
02-analysis/
  python/       Data preparation, source audit, and table/PDF builders
  stata/        Model and graph do-files
  arcgis/       Python and ArcPy scripts for climate and trade maps
03-output/
  figures/      Stata graphs, vector PDFs, and PNGs
    arcgis/     Editable ArcGIS Pro project and map exports
  tables/       Editable LaTeX tables
  results/      Stata estimates and model fit, phase results, and source audit
04-data/
  observed/     NDMA analysis panel and derived weather and outcome data
  sources/      Archived records, regional weather, and crosswalks
  geography/    Stata boundaries and display coordinates
    arcgis/     Prepared map layers, regional climate averages, and trade source audit
```

- [Figures and tables PDF](03-output/Kenya_Maize_Figures_and_Tables.pdf) contains the Stata exhibits, descriptive statistics, and the complete static and matched regression tables.
- [Graph do-file](02-analysis/stata/build_graphs.do) exports each figure as an editable Stata graph, a vector PDF, and a PNG. Figure 1 uses 19 source coordinates and four marked county proxies for locations with conflicting geography.
- Figure 2 tracks the monthly retail price, inflation, and volatility distributions. Figure 3 shows the main static ERA5 estimates and the CHIRPS rainfall check with pointwise 95% intervals across all 23 reporting locations. [Price dynamics](03-output/figures/figure-2-observed-prices.pdf) · [Static estimates](03-output/figures/figure-3-weather-coefficients.pdf)
- Figure 4 shows the distribution of signed ERA5 exposures by crop phase in the Kenya panel. Figure 5 compares static and dynamic estimates using identical observations within each outcome. [Weather exposures](03-output/figures/figure-4-weather-exposures.pdf) · [Matched sample estimates](03-output/figures/figure-5-matched-weather-coefficients.pdf)
- Figures 6a and 6b show monthly ERA5 distributions across the 1981–2005 reference period. Trans Nzoia, Nyandarua, Meru, Narok, Kitui, and Kilifi span the western and central highlands, the Rift Valley, the east, and the coast. Bars give calendar-month means. The boxes show quartiles and medians across the 25 years. [Rainfall](03-output/figures/figure-6a-monthly-rainfall.pdf) · [Temperature](03-output/figures/figure-6b-monthly-temperature.pdf) · [Computed weather distributions](03-output/results/monthly-weather-distributions.csv)
- Figure 7 plots six-month maize inflation volatility with a location-specific LOWESS fit (bandwidth 0.30) for Turkana, Marsabit, Mandera, West Pokot, Nyeri-Kieni, Garissa, Narok, Taita Taveta, and Kwale. The chart uses percentage points. Matching local headline CPI series are unavailable in the bundle. Narok's two missing prices leave eight unusable volatility windows between November 2010 and June 2011. [Market volatility](03-output/figures/figure-7-market-volatility.pdf) · [Computed volatility and LOWESS series](03-output/results/market-volatility-series.csv)

The location panels are chosen for geographic coverage. The regression and coefficient exhibits use the full panel of reporting locations.

## Project background and contributions

I started this project while preparing my master’s thesis as a backup in case IRB approval delayed the start of my RCT. I spent about a month on the project while preparing the IRB application and coordinating with the RCT local team.

I chose to study how weather in maize-supplying regions relates to retail maize price inflation and volatility in Kenya. I led the research design, including the choice of data sources, matching rules, and model comparisons. In Python, I used documented trade routes to link Kenyan markets to growing regions and matched each market-month to weather from the most recently completed planting, growing, and harvest phases. In Stata, I estimated models with market and year-month fixed effects and checked how the estimates changed when we substituted CHIRPS rainfall for ERA5 rainfall. Finally, I used ArcGIS Pro to map regional weather patterns and documented maize trade routes.

I used an AI coding assistant to build the replication package. It includes the source data, analysis files, results, and instructions for rerunning the workflow. We verified that the panel contained 1,932 unique market-month records and 1,930 observed prices. We left the two missing prices in Narok blank and calculated inflation and volatility only when the required consecutive monthly prices were available.

When I encountered unexpected results in the weather matching, I isolated the problem with a small example I could check by hand. The test showed that the code could select the wrong cell when latitude and longitude had different grid spacing. After I corrected the indexing, the workflow reproduced all regional weather records used in the study. I also reused fixed effects calculations in Stata, cutting the number of auxiliary weather regressions in half. The rerun reproduced every exported coefficient and standard error across all 36 models.

## Reproduce the coding sample

Run from the root of this extracted folder. Use the `python3.12` executable to create the virtual environment below. Use Stata 18 or later for the graph do-file. The package includes the Stata-ready geography and regional weather inputs.

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r 02-analysis/python/requirements.txt
.venv/bin/python 02-analysis/python/prepare_ndma_panel.py
.venv/bin/python 02-analysis/python/audit_narok.py
stata -b do 02-analysis/stata/estimate_weather_models.do
.venv/bin/python 02-analysis/python/build_phase_results.py
stata -b do 02-analysis/stata/build_graphs.do
.venv/bin/python 02-analysis/python/build_exhibits.py
```

In desktop Stata, set the working directory to the package root. At the corresponding steps above, run `do 02-analysis/stata/estimate_weather_models.do` and `do 02-analysis/stata/build_graphs.do`.

If your fonts are stored outside the macOS Supplemental folder, pass `--font-dir /path/to/fonts` to `build_exhibits.py`.

## ArcGIS Pro maps

The climate figure maps 1981–2005 mean monthly ERA5 rainfall and 2 m air temperature for the study’s 24 maize-supplying regions. The trade figure traces the routes and production classifications from the FEWS NET first-season map published in 2008. The arrow widths reproduce its qualitative flow categories. [Climate figure](03-output/figures/arcgis/Kenya_Maize_ERA5_Climatology_1981_2005.png) · [Trade figure](03-output/figures/arcgis/Kenya_Maize_Trade_First_Season_2008.png) · [FEWS NET source map](https://fews.net/east-africa/kenya/production-and-trade-flow-map/august-2008-1)

Open the editable project in ArcGIS Pro to inspect both layouts and their layers. To generate the figures from the bundled geography, open a blank ArcGIS Pro project and use **Analysis → Python → Python Window**. Replace the example path with the location of the extracted package as seen by ArcGIS Pro. [Editable ArcGIS Pro project](03-output/figures/arcgis/Kenya_Maize_Climatology_and_Trade.ppkx) · [ArcPy renderer](02-analysis/arcgis/render_reference_maps.py)

```python
import runpy
runpy.run_path(r"C:\path\to\package\02-analysis\arcgis\render_reference_maps.py", run_name="__main__")
```

To rebuild the geographic inputs, run these commands from the package root after creating the Python environment above. The climate script uses the bundled regional weather and catchment links. The trade script uses the bundled FEWS NET coordinate records and downloads its source map and boundaries into a local cache as needed. [Climate preparation](02-analysis/arcgis/prepare_climatology.py) · [Trade digitization](02-analysis/arcgis/digitize_fews_trade.py) · [Trade route audit](04-data/geography/arcgis/FEWS_2008_Digitized_Maize_Routes.csv)

```bash
.venv/bin/python 02-analysis/arcgis/prepare_climatology.py
.venv/bin/python -m pip install -r 02-analysis/arcgis/requirements.txt
.venv/bin/python 02-analysis/arcgis/digitize_fews_trade.py
```

## Price records and weather

Python keeps published NDMA monthly retail prices for local white maize grain from January 2008 through December 2014, in Kenyan shillings per kilogram. Each of the 23 reporting locations maps to a stable FEWS NET series ID. The 1,932 location-month rows include **1,930 observed prices, zero duplicate keys, and two blank prices**, both in Narok (November and December 2010). The source records mark those observations “Not Collected.” The WFP archive is bundled for source auditing only. Stata uses the observed NDMA price series. No prices were imputed. [FEWS NET price query](https://fdw.fews.net/api/marketpricefacts.csv?country_code=KE&product=maize&price_type=Retail) · [WFP Kenya prices](https://data.humdata.org/dataset/wfp-food-prices-for-kenya)

Python merges the 23 reporting locations with 19 fixed maize-supply catchments covering 24 growing areas. The crosswalk uses 2008 FEWS NET trade maps, documented routes, and regional production proxies. Maize harvested area from MapSPAM 2000 weights grid cells within origins. Linked origins receive equal weights within each catchment. These weights represent geography and the prespecified catchment links. Historical monthly shipment shares are unavailable. The baseline assigns Baringo, Kilifi, Makueni, and Samburu by their reporting labels because of conflicting coordinates. A supplementary sample excludes those four sites. [FEWS NET first-season maize map](https://fews.net/east-africa/kenya/production-and-trade-flow-map/august-2008-1) · [FEWS NET second-season maize map](https://fews.net/east-africa/kenya/production-and-trade-flow-map/august-2008-2) · [MapSPAM 2000](https://doi.org/10.7910/DVN/A50I2T)

Monthly weather uses ERA5 rainfall and 2 m air temperature, with CHIRPS v3 rainfall as a check. Within each origin and variable, Python fits calendar-month effects and a linear trend using only January 1981 through December 2005. Anomalies are observed values minus fitted values. The phase calendar uses the most recent completed occurrence of each phase before the price month. Python sums rainfall anomalies over the phase and averages temperature anomalies by days in each month. Phase dates are recorded separately, and the matched phases can come from different crop cycles. [ERA5](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels) · [CHIRPS v3](https://www.chc.ucsb.edu/data/chirps3) · [FEWS NET Kenya country book](https://help.fews.net/fde/v3/kenya-country-book) · [JRC African crop calendars](https://datacatalog.worldbank.org/search/dataset/0066842/crop-calendar-for-africa)

Before weighting weather exposure, the pipeline requires unique catchment–origin links, unique origin–month–phase records, and complete weather coverage for linked origins. These checks also run with Python optimization enabled.

## Econometric model

The main model uses ERA5 rainfall and temperature with location and year-month fixed effects. Each phase contributes four regressors, the deficit and excess magnitudes of rainfall and of temperature. The static regression uses every observed outcome window. Its identifying variation comes from differences in weather exposure across reporting locations within a given month. Common national prices and exchange rates are absorbed by year-month effects, and fixed distances are absorbed by location effects. The panel lacks verified location-specific monthly trade volumes. We estimate conditional associations.

Inflation is 100 times the log price change from the preceding calendar month. Volatility is the sample standard deviation of six consecutive monthly inflation rates ending in the current month. These outcomes require two and seven consecutive observed prices, respectively, within a single NDMA series. Stata reconstructs the windows with calendar lags before restricting any sample, then checks the results against the Python panel. [Cardell and Michelson (2023), Section 2.1](https://onlinelibrary.wiley.com/doi/10.1111/ajae.12343)

The rainfall check replaces ERA5 rainfall with CHIRPS and retains ERA5 temperature. The dynamic check adds one calendar-month lag of the relevant outcome, which requires three consecutive prices for inflation and eight for volatility. The matched static model uses those same location-months. Volatility windows in adjacent months share five of six inflation rates, so lagged volatility captures substantial persistence. For each model, the weather-free baseline has the same sample and includes the outcome lag when applicable. Stata reports a 12-month Bartlett HAC covariance from monthly sums of regression scores. The coefficients file includes pointwise 95% intervals and the model-fit file includes the joint weather tests.

Section V provides the crop-phase modeling framework in equations (5) and (5′). Figures 2, 8, 10, and 13 inform the exhibit formats.

## Results by crop phase

[The phase-by-phase CSV](03-output/results/crop-phase-results.csv) contains the 144 estimates for the full sample across the static, matched static, and dynamic models for both rainfall sources. Effects are in percentage points for a 50 mm larger rainfall deficit or excess, or for a 1 °C larger cool or warm temperature deviation. Intervals are pointwise 95% confidence intervals for individual coefficients.

The main comparison is static ERA5 versus static CHIRPS. The matched static and dynamic results each use their own weather-free baseline. [Model fit by specification](03-output/results/model-fit.csv)

## Analysis files and data

| Path | Purpose |
|---|---|
| `02-analysis/python/prepare_ndma_panel.py`, `02-analysis/python/weather.py` | Build the calendar panel, monthly normals and anomalies, phase dates, catchment weights, and outcome windows. |
| `02-analysis/python/audit_narok.py` | Check the FEWS NET and WFP archives for the two blank Narok dates. |
| `02-analysis/stata/estimate_weather_models.do` | Recompute the outcome windows, estimate the main model and robustness checks, and write the estimates. |
| `02-analysis/stata/build_graphs.do`, `02-analysis/stata/build_location_graphs.do` | Draw the Stata figures and export the monthly weather and market volatility values. |
| `02-analysis/arcgis/` | Prepare the climate and trade inputs and render both layouts with ArcPy. |
| `02-analysis/python/build_phase_results.py`, `02-analysis/python/build_exhibits.py` | Format the phase results and build the figures and tables PDF. |
| `04-data/observed/ndma-market-month-panel.csv` | Complete calendar grid with observed NDMA prices, FEWS NET IDs, weather exposures, and outcome windows. |
| `04-data/observed/origin-month-weather-anomalies.csv`, `04-data/observed/origin-most-recent-crop-phase.csv` | Monthly inputs, fitted values and anomalies for 24 origins, and 6,048 dated phase assignments. |
| `04-data/sources/`, `04-data/geography/` | Original archive records, market catchments, crop calendars, regional weather and Stata map input. |
| `03-output/results/crop-phase-results.csv`, `model-fit.csv`, `coefficients.csv` | Full-sample phase estimates, diagnostics, and complete Stata results. The Stata outputs include the 22-location balanced and 19-location geography checks. |

`02-analysis/python/rebuild_regional_weather.py` verifies the bundled regional inputs using the separate upstream weather archive and `02-analysis/python/requirements-native.txt`. `02-analysis/python/prepare_map_geometry.py` recreates the Stata map inputs if the extracted `kenya-maize-weather-data` archive sits alongside this folder. The main commands use the bundled regional weather and geography files.